<!doctype html>
<html lang="en-US">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge"><script type="text/javascript">(window.NREUM||(NREUM={})).init={ajax:{deny_list:["bam.nr-data.net"]}};(window.NREUM||(NREUM={})).loader_config={licenseKey:"NRJS-1cbf18cb11c6a4f89a0",applicationID:"1546597350"};;/*! For license information please see nr-loader-rum-1.293.0.min.js.LICENSE.txt */
(()=>{var e,t,r={122:(e,t,r)=>{"use strict";r.d(t,{a:()=>i});var n=r(944);function i(e,t){try{if(!e||"object"!=typeof e)return(0,n.R)(3);if(!t||"object"!=typeof t)return(0,n.R)(4);const r=Object.create(Object.getPrototypeOf(t),Object.getOwnPropertyDescriptors(t)),a=0===Object.keys(r).length?e:r;for(let o in a)if(void 0!==e[o])try{if(null===e[o]){r[o]=null;continue}Array.isArray(e[o])&&Array.isArray(t[o])?r[o]=Array.from(new Set([...e[o],...t[o]])):"object"==typeof e[o]&&"object"==typeof t[o]?r[o]=i(e[o],t[o]):r[o]=e[o]}catch(e){r[o]||(0,n.R)(1,e)}return r}catch(e){(0,n.R)(2,e)}}},555:(e,t,r)=>{"use strict";r.d(t,{D:()=>s,f:()=>o});var n=r(384),i=r(122);const a={beacon:n.NT.beacon,errorBeacon:n.NT.errorBeacon,licenseKey:void 0,applicationID:void 0,sa:void 0,queueTime:void 0,applicationTime:void 0,ttGuid:void 0,user:void 0,account:void 0,product:void 0,extra:void 0,jsAttributes:{},userAttributes:void 0,atts:void 0,transactionName:void 0,tNamePlain:void 0};function o(e){try{return!!e.licenseKey&&!!e.errorBeacon&&!!e.applicationID}catch(e){return!1}}const s=e=>(0,i.a)(e,a)},324:(e,t,r)=>{"use strict";r.d(t,{F3:()=>i,Xs:()=>a,xv:()=>n});const n="1.293.0",i="PROD",a="CDN"},154:(e,t,r)=>{"use strict";r.d(t,{OF:()=>c,RI:()=>i,WN:()=>d,bv:()=>a,gm:()=>o,mw:()=>s,sb:()=>u});var n=r(863);const i="undefined"!=typeof window&&!!window.document,a="undefined"!=typeof WorkerGlobalScope&&("undefined"!=typeof self&&self instanceof WorkerGlobalScope&&self.navigator instanceof WorkerNavigator||"undefined"!=typeof globalThis&&globalThis instanceof WorkerGlobalScope&&globalThis.navigator instanceof WorkerNavigator),o=i?window:"undefined"!=typeof WorkerGlobalScope&&("undefined"!=typeof self&&self instanceof WorkerGlobalScope&&self||"undefined"!=typeof globalThis&&globalThis instanceof WorkerGlobalScope&&globalThis),s=Boolean("hidden"===o?.document?.visibilityState),c=/iPad|iPhone|iPod/.test(o.navigator?.userAgent),u=c&&"undefined"==typeof SharedWorker,d=((()=>{const e=o.navigator?.userAgent?.match(/Firefox[/\s](\d+\.\d+)/);Array.isArray(e)&&e.length>=2&&e[1]})(),Date.now()-(0,n.t)())},241:(e,t,r)=>{"use strict";r.d(t,{W:()=>a});var n=r(154);const i="newrelic";function a(e={}){try{n.gm.dispatchEvent(new CustomEvent(i,{detail:e}))}catch(e){}}},687:(e,t,r)=>{"use strict";r.d(t,{Ak:()=>u,Ze:()=>f,x3:()=>d});var n=r(241),i=r(836),a=r(606),o=r(860),s=r(646);const c={};function u(e,t){const r={staged:!1,priority:o.P3[t]||0};l(e),c[e].get(t)||c[e].set(t,r)}function d(e,t){e&&c[e]&&(c[e].get(t)&&c[e].delete(t),p(e,t,!1),c[e].size&&g(e))}function l(e){if(!e)throw new Error("agentIdentifier required");c[e]||(c[e]=new Map)}function f(e="",t="feature",r=!1){if(l(e),!e||!c[e].get(t)||r)return p(e,t);c[e].get(t).staged=!0,g(e)}function g(e){const t=Array.from(c[e]);t.every((([e,t])=>t.staged))&&(t.sort(((e,t)=>e[1].priority-t[1].priority)),t.forEach((([t])=>{c[e].delete(t),p(e,t)})))}function p(e,t,r=!0){const o=e?i.ee.get(e):i.ee,c=a.i.handlers;if(!o.aborted&&o.backlog&&c){if((0,n.W)({agentIdentifier:e,type:"lifecycle",name:"drain",feature:t}),r){const e=o.backlog[t],r=c[t];if(r){for(let t=0;e&&t<e.length;++t)m(e[t],r);Object.entries(r).forEach((([e,t])=>{Object.values(t||{}).forEach((t=>{t[0]?.on&&t[0]?.context()instanceof s.y&&t[0].on(e,t[1])}))}))}}o.isolatedBacklog||delete c[t],o.backlog[t]=null,o.emit("drain-"+t,[])}}function m(e,t){var r=e[1];Object.values(t[r]||{}).forEach((t=>{var r=e[0];if(t[0]===r){var n=t[1],i=e[3],a=e[2];n.apply(i,a)}}))}},836:(e,t,r)=>{"use strict";r.d(t,{P:()=>s,ee:()=>c});var n=r(384),i=r(990),a=r(646),o=r(607);const s="nr@context:".concat(o.W),c=function e(t,r){var n={},o={},d={},l=!1;try{l=16===r.length&&u.initializedAgents?.[r]?.runtime.isolatedBacklog}catch(e){}var f={on:p,addEventListener:p,removeEventListener:function(e,t){var r=n[e];if(!r)return;for(var i=0;i<r.length;i++)r[i]===t&&r.splice(i,1)},emit:function(e,r,n,i,a){!1!==a&&(a=!0);if(c.aborted&&!i)return;t&&a&&t.emit(e,r,n);for(var s=g(n),u=m(e),d=u.length,l=0;l<d;l++)u[l].apply(s,r);var p=v()[o[e]];p&&p.push([f,e,r,s]);return s},get:h,listeners:m,context:g,buffer:function(e,t){const r=v();if(t=t||"feature",f.aborted)return;Object.entries(e||{}).forEach((([e,n])=>{o[n]=t,t in r||(r[t]=[])}))},abort:function(){f._aborted=!0,Object.keys(f.backlog).forEach((e=>{delete f.backlog[e]}))},isBuffering:function(e){return!!v()[o[e]]},debugId:r,backlog:l?{}:t&&"object"==typeof t.backlog?t.backlog:{},isolatedBacklog:l};return Object.defineProperty(f,"aborted",{get:()=>{let e=f._aborted||!1;return e||(t&&(e=t.aborted),e)}}),f;function g(e){return e&&e instanceof a.y?e:e?(0,i.I)(e,s,(()=>new a.y(s))):new a.y(s)}function p(e,t){n[e]=m(e).concat(t)}function m(e){return n[e]||[]}function h(t){return d[t]=d[t]||e(f,t)}function v(){return f.backlog}}(void 0,"globalEE"),u=(0,n.Zm)();u.ee||(u.ee=c)},646:(e,t,r)=>{"use strict";r.d(t,{y:()=>n});class n{constructor(e){this.contextId=e}}},908:(e,t,r)=>{"use strict";r.d(t,{d:()=>n,p:()=>i});var n=r(836).ee.get("handle");function i(e,t,r,i,a){a?(a.buffer([e],i),a.emit(e,t,r)):(n.buffer([e],i),n.emit(e,t,r))}},606:(e,t,r)=>{"use strict";r.d(t,{i:()=>a});var n=r(908);a.on=o;var i=a.handlers={};function a(e,t,r,a){o(a||n.d,i,e,t,r)}function o(e,t,r,i,a){a||(a="feature"),e||(e=n.d);var o=t[a]=t[a]||{};(o[r]=o[r]||[]).push([e,i])}},878:(e,t,r)=>{"use strict";function n(e,t){return{capture:e,passive:!1,signal:t}}function i(e,t,r=!1,i){window.addEventListener(e,t,n(r,i))}function a(e,t,r=!1,i){document.addEventListener(e,t,n(r,i))}r.d(t,{DD:()=>a,jT:()=>n,sp:()=>i})},607:(e,t,r)=>{"use strict";r.d(t,{W:()=>n});const n=(0,r(566).bz)()},566:(e,t,r)=>{"use strict";r.d(t,{LA:()=>s,bz:()=>o});var n=r(154);const i="xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx";function a(e,t){return e?15&e[t]:16*Math.random()|0}function o(){const e=n.gm?.crypto||n.gm?.msCrypto;let t,r=0;return e&&e.getRandomValues&&(t=e.getRandomValues(new Uint8Array(30))),i.split("").map((e=>"x"===e?a(t,r++).toString(16):"y"===e?(3&a()|8).toString(16):e)).join("")}function s(e){const t=n.gm?.crypto||n.gm?.msCrypto;let r,i=0;t&&t.getRandomValues&&(r=t.getRandomValues(new Uint8Array(e)));const o=[];for(var s=0;s<e;s++)o.push(a(r,i++).toString(16));return o.join("")}},614:(e,t,r)=>{"use strict";r.d(t,{BB:()=>o,H3:()=>n,g:()=>u,iL:()=>c,tS:()=>s,uh:()=>i,wk:()=>a});const n="NRBA",i="SESSION",a=144e5,o=18e5,s={STARTED:"session-started",PAUSE:"session-pause",RESET:"session-reset",RESUME:"session-resume",UPDATE:"session-update"},c={SAME_TAB:"same-tab",CROSS_TAB:"cross-tab"},u={OFF:0,FULL:1,ERROR:2}},863:(e,t,r)=>{"use strict";function n(){return Math.floor(performance.now())}r.d(t,{t:()=>n})},944:(e,t,r)=>{"use strict";r.d(t,{R:()=>i});var n=r(241);function i(e,t){"function"==typeof console.debug&&(console.debug("New Relic Warning: https://github.com/newrelic/newrelic-browser-agent/blob/main/docs/warning-codes.md#".concat(e),t),(0,n.W)({agentIdentifier:null,drained:null,type:"data",name:"warn",feature:"warn",data:{code:e,secondary:t}}))}},701:(e,t,r)=>{"use strict";r.d(t,{B:()=>a,t:()=>o});var n=r(241);const i=new Set,a={};function o(e,t){const r=t.agentIdentifier;a[r]??={},e&&"object"==typeof e&&(i.has(r)||(t.ee.emit("rumresp",[e]),a[r]=e,i.add(r),(0,n.W)({agentIdentifier:r,loaded:!0,drained:!0,type:"lifecycle",name:"load",feature:void 0,data:e})))}},990:(e,t,r)=>{"use strict";r.d(t,{I:()=>i});var n=Object.prototype.hasOwnProperty;function i(e,t,r){if(n.call(e,t))return e[t];var i=r();if(Object.defineProperty&&Object.keys)try{return Object.defineProperty(e,t,{value:i,writable:!0,enumerable:!1}),i}catch(e){}return e[t]=i,i}},389:(e,t,r)=>{"use strict";function n(e,t=500,r={}){const n=r?.leading||!1;let i;return(...r)=>{n&&void 0===i&&(e.apply(this,r),i=setTimeout((()=>{i=clearTimeout(i)}),t)),n||(clearTimeout(i),i=setTimeout((()=>{e.apply(this,r)}),t))}}function i(e){let t=!1;return(...r)=>{t||(t=!0,e.apply(this,r))}}r.d(t,{J:()=>i,s:()=>n})},289:(e,t,r)=>{"use strict";r.d(t,{GG:()=>a,Qr:()=>s,sB:()=>o});var n=r(878);function i(){return"undefined"==typeof document||"complete"===document.readyState}function a(e,t){if(i())return e();(0,n.sp)("load",e,t)}function o(e){if(i())return e();(0,n.DD)("DOMContentLoaded",e)}function s(e){if(i())return e();(0,n.sp)("popstate",e)}},384:(e,t,r)=>{"use strict";r.d(t,{NT:()=>a,US:()=>u,Zm:()=>o,bQ:()=>c,dV:()=>s,pV:()=>d});var n=r(154),i=r(863);const a={beacon:"bam.nr-data.net",errorBeacon:"bam.nr-data.net"};function o(){return n.gm.NREUM||(n.gm.NREUM={}),void 0===n.gm.newrelic&&(n.gm.newrelic=n.gm.NREUM),n.gm.NREUM}function s(){let e=o();return e.o||(e.o={ST:n.gm.setTimeout,SI:n.gm.setImmediate,CT:n.gm.clearTimeout,XHR:n.gm.XMLHttpRequest,REQ:n.gm.Request,EV:n.gm.Event,PR:n.gm.Promise,MO:n.gm.MutationObserver,FETCH:n.gm.fetch,WS:n.gm.WebSocket}),e}function c(e,t){let r=o();r.initializedAgents??={},t.initializedAt={ms:(0,i.t)(),date:new Date},r.initializedAgents[e]=t}function u(e,t){o()[e]=t}function d(){return function(){let e=o();const t=e.info||{};e.info={beacon:a.beacon,errorBeacon:a.errorBeacon,...t}}(),function(){let e=o();const t=e.init||{};e.init={...t}}(),s(),function(){let e=o();const t=e.loader_config||{};e.loader_config={...t}}(),o()}},843:(e,t,r)=>{"use strict";r.d(t,{u:()=>i});var n=r(878);function i(e,t=!1,r,i){(0,n.DD)("visibilitychange",(function(){if(t)return void("hidden"===document.visibilityState&&e());e(document.visibilityState)}),r,i)}},773:(e,t,r)=>{"use strict";r.d(t,{z_:()=>a,XG:()=>s,TZ:()=>n,rs:()=>i,xV:()=>o});r(154),r(566),r(384);const n=r(860).K7.metrics,i="sm",a="cm",o="storeSupportabilityMetrics",s="storeEventMetrics"},630:(e,t,r)=>{"use strict";r.d(t,{T:()=>n});const n=r(860).K7.pageViewEvent},782:(e,t,r)=>{"use strict";r.d(t,{T:()=>n});const n=r(860).K7.pageViewTiming},234:(e,t,r)=>{"use strict";r.d(t,{W:()=>a});var n=r(836),i=r(687);class a{constructor(e,t){this.agentIdentifier=e,this.ee=n.ee.get(e),this.featureName=t,this.blocked=!1}deregisterDrain(){(0,i.x3)(this.agentIdentifier,this.featureName)}}},741:(e,t,r)=>{"use strict";r.d(t,{W:()=>a});var n=r(944),i=r(261);class a{#e(e,...t){if(this[e]!==a.prototype[e])return this[e](...t);(0,n.R)(35,e)}addPageAction(e,t){return this.#e(i.hG,e,t)}register(e){return this.#e(i.eY,e)}recordCustomEvent(e,t){return this.#e(i.fF,e,t)}setPageViewName(e,t){return this.#e(i.Fw,e,t)}setCustomAttribute(e,t,r){return this.#e(i.cD,e,t,r)}noticeError(e,t){return this.#e(i.o5,e,t)}setUserId(e){return this.#e(i.Dl,e)}setApplicationVersion(e){return this.#e(i.nb,e)}setErrorHandler(e){return this.#e(i.bt,e)}addRelease(e,t){return this.#e(i.k6,e,t)}log(e,t){return this.#e(i.$9,e,t)}start(){return this.#e(i.d3)}finished(e){return this.#e(i.BL,e)}recordReplay(){return this.#e(i.CH)}pauseReplay(){return this.#e(i.Tb)}addToTrace(e){return this.#e(i.U2,e)}setCurrentRouteName(e){return this.#e(i.PA,e)}interaction(){return this.#e(i.dT)}wrapLogger(e,t,r){return this.#e(i.Wb,e,t,r)}measure(e,t){return this.#e(i.V1,e,t)}}},261:(e,t,r)=>{"use strict";r.d(t,{$9:()=>u,BL:()=>s,CH:()=>g,Dl:()=>_,Fw:()=>y,PA:()=>h,Pl:()=>n,Tb:()=>l,U2:()=>a,V1:()=>k,Wb:()=>x,bt:()=>b,cD:()=>v,d3:()=>w,dT:()=>c,eY:()=>p,fF:()=>f,hG:()=>i,k6:()=>o,nb:()=>m,o5:()=>d});const n="api-",i="addPageAction",a="addToTrace",o="addRelease",s="finished",c="interaction",u="log",d="noticeError",l="pauseReplay",f="recordCustomEvent",g="recordReplay",p="register",m="setApplicationVersion",h="setCurrentRouteName",v="setCustomAttribute",b="setErrorHandler",y="setPageViewName",_="setUserId",w="start",x="wrapLogger",k="measure"},163:(e,t,r)=>{"use strict";r.d(t,{j:()=>E});var n=r(384),i=r(741);var a=r(555);r(860).K7.genericEvents;const o="experimental.marks",s="experimental.measures",c="experimental.resources",u=e=>{if(!e||"string"!=typeof e)return!1;try{document.createDocumentFragment().querySelector(e)}catch{return!1}return!0};var d=r(614),l=r(944),f=r(122);const g="[data-nr-mask]",p=e=>(0,f.a)(e,(()=>{const e={feature_flags:[],experimental:{marks:!1,measures:!1,resources:!1},mask_selector:"*",block_selector:"[data-nr-block]",mask_input_options:{color:!1,date:!1,"datetime-local":!1,email:!1,month:!1,number:!1,range:!1,search:!1,tel:!1,text:!1,time:!1,url:!1,week:!1,textarea:!1,select:!1,password:!0}};return{ajax:{deny_list:void 0,block_internal:!0,enabled:!0,autoStart:!0},api:{allow_registered_children:!0,duplicate_registered_data:!1},distributed_tracing:{enabled:void 0,exclude_newrelic_header:void 0,cors_use_newrelic_header:void 0,cors_use_tracecontext_headers:void 0,allowed_origins:void 0},get feature_flags(){return e.feature_flags},set feature_flags(t){e.feature_flags=t},generic_events:{enabled:!0,autoStart:!0},harvest:{interval:30},jserrors:{enabled:!0,autoStart:!0},logging:{enabled:!0,autoStart:!0},metrics:{enabled:!0,autoStart:!0},obfuscate:void 0,page_action:{enabled:!0},page_view_event:{enabled:!0,autoStart:!0},page_view_timing:{enabled:!0,autoStart:!0},performance:{get capture_marks(){return e.feature_flags.includes(o)||e.experimental.marks},set capture_marks(t){e.experimental.marks=t},get capture_measures(){return e.feature_flags.includes(s)||e.experimental.measures},set capture_measures(t){e.experimental.measures=t},capture_detail:!0,resources:{get enabled(){return e.feature_flags.includes(c)||e.experimental.resources},set enabled(t){e.experimental.resources=t},asset_types:[],first_party_domains:[],ignore_newrelic:!0}},privacy:{cookies_enabled:!0},proxy:{assets:void 0,beacon:void 0},session:{expiresMs:d.wk,inactiveMs:d.BB},session_replay:{autoStart:!0,enabled:!1,preload:!1,sampling_rate:10,error_sampling_rate:100,collect_fonts:!1,inline_images:!1,fix_stylesheets:!0,mask_all_inputs:!0,get mask_text_selector(){return e.mask_selector},set mask_text_selector(t){u(t)?e.mask_selector="".concat(t,",").concat(g):""===t||null===t?e.mask_selector=g:(0,l.R)(5,t)},get block_class(){return"nr-block"},get ignore_class(){return"nr-ignore"},get mask_text_class(){return"nr-mask"},get block_selector(){return e.block_selector},set block_selector(t){u(t)?e.block_selector+=",".concat(t):""!==t&&(0,l.R)(6,t)},get mask_input_options(){return e.mask_input_options},set mask_input_options(t){t&&"object"==typeof t?e.mask_input_options={...t,password:!0}:(0,l.R)(7,t)}},session_trace:{enabled:!0,autoStart:!0},soft_navigations:{enabled:!0,autoStart:!0},spa:{enabled:!0,autoStart:!0},ssl:void 0,user_actions:{enabled:!0,elementAttributes:["id","className","tagName","type"]}}})());var m=r(154),h=r(324);let v=0;const b={buildEnv:h.F3,distMethod:h.Xs,version:h.xv,originTime:m.WN},y={appMetadata:{},customTransaction:void 0,denyList:void 0,disabled:!1,entityManager:void 0,harvester:void 0,isolatedBacklog:!1,isRecording:!1,loaderType:void 0,maxBytes:3e4,obfuscator:void 0,onerror:void 0,ptid:void 0,releaseIds:{},session:void 0,timeKeeper:void 0,get harvestCount(){return++v}},_=e=>{const t=(0,f.a)(e,y),r=Object.keys(b).reduce(((e,t)=>(e[t]={value:b[t],writable:!1,configurable:!0,enumerable:!0},e)),{});return Object.defineProperties(t,r)};var w=r(701);const x=e=>{const t=e.startsWith("http");e+="/",r.p=t?e:"https://"+e};var k=r(836),A=r(241);const S={accountID:void 0,trustKey:void 0,agentID:void 0,licenseKey:void 0,applicationID:void 0,xpid:void 0},T=e=>(0,f.a)(e,S),R=new Set;function E(e,t={},r,o){let{init:s,info:c,loader_config:u,runtime:d={},exposed:l=!0}=t;if(!c){const e=(0,n.pV)();s=e.init,c=e.info,u=e.loader_config}e.init=p(s||{}),e.loader_config=T(u||{}),c.jsAttributes??={},m.bv&&(c.jsAttributes.isWorker=!0),e.info=(0,a.D)(c);const f=e.init,g=[c.beacon,c.errorBeacon];R.has(e.agentIdentifier)||(f.proxy.assets&&(x(f.proxy.assets),g.push(f.proxy.assets)),f.proxy.beacon&&g.push(f.proxy.beacon),function(e){const t=(0,n.pV)();Object.getOwnPropertyNames(i.W.prototype).forEach((r=>{const n=i.W.prototype[r];if("function"!=typeof n||"constructor"===n)return;let a=t[r];e[r]&&!1!==e.exposed&&"micro-agent"!==e.runtime?.loaderType&&(t[r]=(...t)=>{const n=e[r](...t);return a?a(...t):n})}))}(e),(0,n.US)("activatedFeatures",w.B),e.runSoftNavOverSpa&&=!0===f.soft_navigations.enabled&&f.feature_flags.includes("soft_nav")),d.denyList=[...f.ajax.deny_list||[],...f.ajax.block_internal?g:[]],d.ptid=e.agentIdentifier,d.loaderType=r,e.runtime=_(d),R.has(e.agentIdentifier)||(e.ee=k.ee.get(e.agentIdentifier),e.exposed=l,(0,A.W)({agentIdentifier:e.agentIdentifier,drained:!!w.B?.[e.agentIdentifier],type:"lifecycle",name:"initialize",feature:void 0,data:e.config})),R.add(e.agentIdentifier)}},374:(e,t,r)=>{r.nc=(()=>{try{return document?.currentScript?.nonce}catch(e){}return""})()},860:(e,t,r)=>{"use strict";r.d(t,{$J:()=>d,K7:()=>c,P3:()=>u,XX:()=>i,Yy:()=>s,df:()=>a,qY:()=>n,v4:()=>o});const n="events",i="jserrors",a="browser/blobs",o="rum",s="browser/logs",c={ajax:"ajax",genericEvents:"generic_events",jserrors:i,logging:"logging",metrics:"metrics",pageAction:"page_action",pageViewEvent:"page_view_event",pageViewTiming:"page_view_timing",sessionReplay:"session_replay",sessionTrace:"session_trace",softNav:"soft_navigations",spa:"spa"},u={[c.pageViewEvent]:1,[c.pageViewTiming]:2,[c.metrics]:3,[c.jserrors]:4,[c.spa]:5,[c.ajax]:6,[c.sessionTrace]:7,[c.softNav]:8,[c.sessionReplay]:9,[c.logging]:10,[c.genericEvents]:11},d={[c.pageViewEvent]:o,[c.pageViewTiming]:n,[c.ajax]:n,[c.spa]:n,[c.softNav]:n,[c.metrics]:i,[c.jserrors]:i,[c.sessionTrace]:a,[c.sessionReplay]:a,[c.logging]:s,[c.genericEvents]:"ins"}}},n={};function i(e){var t=n[e];if(void 0!==t)return t.exports;var a=n[e]={exports:{}};return r[e](a,a.exports,i),a.exports}i.m=r,i.d=(e,t)=>{for(var r in t)i.o(t,r)&&!i.o(e,r)&&Object.defineProperty(e,r,{enumerable:!0,get:t[r]})},i.f={},i.e=e=>Promise.all(Object.keys(i.f).reduce(((t,r)=>(i.f[r](e,t),t)),[])),i.u=e=>"nr-rum-1.293.0.min.js",i.o=(e,t)=>Object.prototype.hasOwnProperty.call(e,t),e={},t="NRBA-1.293.0.PROD:",i.l=(r,n,a,o)=>{if(e[r])e[r].push(n);else{var s,c;if(void 0!==a)for(var u=document.getElementsByTagName("script"),d=0;d<u.length;d++){var l=u[d];if(l.getAttribute("src")==r||l.getAttribute("data-webpack")==t+a){s=l;break}}if(!s){c=!0;var f={296:"sha512-M1viQxU/Sd10c/wA0iJyMGykq7mUO4/cNh2pUlWVWSRdp2RUo2Lmen9N19KuzHKjUln7vOC7HGbkzvGvRT/yQg=="};(s=document.createElement("script")).charset="utf-8",s.timeout=120,i.nc&&s.setAttribute("nonce",i.nc),s.setAttribute("data-webpack",t+a),s.src=r,0!==s.src.indexOf(window.location.origin+"/")&&(s.crossOrigin="anonymous"),f[o]&&(s.integrity=f[o])}e[r]=[n];var g=(t,n)=>{s.onerror=s.onload=null,clearTimeout(p);var i=e[r];if(delete e[r],s.parentNode&&s.parentNode.removeChild(s),i&&i.forEach((e=>e(n))),t)return t(n)},p=setTimeout(g.bind(null,void 0,{type:"timeout",target:s}),12e4);s.onerror=g.bind(null,s.onerror),s.onload=g.bind(null,s.onload),c&&document.head.appendChild(s)}},i.r=e=>{"undefined"!=typeof Symbol&&Symbol.toStringTag&&Object.defineProperty(e,Symbol.toStringTag,{value:"Module"}),Object.defineProperty(e,"__esModule",{value:!0})},i.p="https://js-agent.newrelic.com/",(()=>{var e={374:0,840:0};i.f.j=(t,r)=>{var n=i.o(e,t)?e[t]:void 0;if(0!==n)if(n)r.push(n[2]);else{var a=new Promise(((r,i)=>n=e[t]=[r,i]));r.push(n[2]=a);var o=i.p+i.u(t),s=new Error;i.l(o,(r=>{if(i.o(e,t)&&(0!==(n=e[t])&&(e[t]=void 0),n)){var a=r&&("load"===r.type?"missing":r.type),o=r&&r.target&&r.target.src;s.message="Loading chunk "+t+" failed.\n("+a+": "+o+")",s.name="ChunkLoadError",s.type=a,s.request=o,n[1](s)}}),"chunk-"+t,t)}};var t=(t,r)=>{var n,a,[o,s,c]=r,u=0;if(o.some((t=>0!==e[t]))){for(n in s)i.o(s,n)&&(i.m[n]=s[n]);if(c)c(i)}for(t&&t(r);u<o.length;u++)a=o[u],i.o(e,a)&&e[a]&&e[a][0](),e[a]=0},r=self["webpackChunk:NRBA-1.293.0.PROD"]=self["webpackChunk:NRBA-1.293.0.PROD"]||[];r.forEach(t.bind(null,0)),r.push=t.bind(null,r.push.bind(r))})(),(()=>{"use strict";i(374);var e=i(566),t=i(741);class r extends t.W{agentIdentifier=(0,e.LA)(16)}var n=i(860);const a=Object.values(n.K7);var o=i(163);var s=i(908),c=i(863),u=i(261),d=i(241),l=i(944),f=i(701),g=i(773);function p(e,t,i,a){const o=a||i;!o||o[e]&&o[e]!==r.prototype[e]||(o[e]=function(){(0,s.p)(g.xV,["API/"+e+"/called"],void 0,n.K7.metrics,i.ee),(0,d.W)({agentIdentifier:i.agentIdentifier,drained:!!f.B?.[i.agentIdentifier],type:"data",name:"api",feature:u.Pl+e,data:{}});try{return t.apply(this,arguments)}catch(e){(0,l.R)(23,e)}})}function m(e,t,r,n,i){const a=e.info;null===r?delete a.jsAttributes[t]:a.jsAttributes[t]=r,(i||null===r)&&(0,s.p)(u.Pl+n,[(0,c.t)(),t,r],void 0,"session",e.ee)}var h=i(687),v=i(234),b=i(289),y=i(154),_=i(384);const w=e=>y.RI&&!0===e?.privacy.cookies_enabled;function x(e){return!!(0,_.dV)().o.MO&&w(e)&&!0===e?.session_trace.enabled}var k=i(389);class A extends v.W{constructor(e,t){super(e.agentIdentifier,t),this.abortHandler=void 0,this.featAggregate=void 0,this.onAggregateImported=void 0,this.deferred=Promise.resolve(),!1===e.init[this.featureName].autoStart?this.deferred=new Promise(((t,r)=>{this.ee.on("manual-start-all",(0,k.J)((()=>{(0,h.Ak)(e.agentIdentifier,this.featureName),t()})))})):(0,h.Ak)(e.agentIdentifier,t)}importAggregator(e,t,r={}){if(this.featAggregate)return;let a;this.onAggregateImported=new Promise((e=>{a=e}));const o=async()=>{let o;await this.deferred;try{if(w(e.init)){const{setupAgentSession:t}=await i.e(296).then(i.bind(i,663));o=t(e)}}catch(e){(0,l.R)(20,e),this.ee.emit("internal-error",[e]),this.featureName===n.K7.sessionReplay&&this.abortHandler?.()}try{if(!this.#t(this.featureName,o,e.init))return(0,h.Ze)(this.agentIdentifier,this.featureName),void a(!1);const{Aggregate:n}=await t();this.featAggregate=new n(e,r),e.runtime.harvester.initializedAggregates.push(this.featAggregate),a(!0)}catch(e){(0,l.R)(34,e),this.abortHandler?.(),(0,h.Ze)(this.agentIdentifier,this.featureName,!0),a(!1),this.ee&&this.ee.abort()}};y.RI?(0,b.GG)((()=>o()),!0):o()}#t(e,t,r){switch(e){case n.K7.sessionReplay:return x(r)&&!!t;case n.K7.sessionTrace:return!!t;default:return!0}}}var S=i(630),T=i(614);class R extends A{static featureName=S.T;constructor(e){var t;super(e,S.T),this.setupInspectionEvents(e.agentIdentifier),t=e,p(u.Fw,(function(e,r){"string"==typeof e&&("/"!==e.charAt(0)&&(e="/"+e),t.runtime.customTransaction=(r||"http://custom.transaction")+e,(0,s.p)(u.Pl+u.Fw,[(0,c.t)()],void 0,void 0,t.ee))}),t),this.ee.on("api-send-rum",((e,t)=>(0,s.p)("send-rum",[e,t],void 0,this.featureName,this.ee))),this.importAggregator(e,(()=>i.e(296).then(i.bind(i,108))))}setupInspectionEvents(e){const t=(t,r)=>{t&&(0,d.W)({agentIdentifier:e,timeStamp:t.timeStamp,loaded:"complete"===t.target.readyState,type:"window",name:r,data:t.target.location+""})};(0,b.sB)((e=>{t(e,"DOMContentLoaded")})),(0,b.GG)((e=>{t(e,"load")})),(0,b.Qr)((e=>{t(e,"navigate")})),this.ee.on(T.tS.UPDATE,((t,r)=>{(0,d.W)({agentIdentifier:e,type:"lifecycle",name:"session",data:r})}))}}var E=i(843),N=i(878),j=i(782);class I extends A{static featureName=j.T;constructor(e){super(e,j.T),y.RI&&((0,E.u)((()=>(0,s.p)("docHidden",[(0,c.t)()],void 0,j.T,this.ee)),!0),(0,N.sp)("pagehide",(()=>(0,s.p)("winPagehide",[(0,c.t)()],void 0,j.T,this.ee))),this.importAggregator(e,(()=>i.e(296).then(i.bind(i,350)))))}}class O extends A{static featureName=g.TZ;constructor(e){super(e,g.TZ),y.RI&&document.addEventListener("securitypolicyviolation",(e=>{(0,s.p)(g.xV,["Generic/CSPViolation/Detected"],void 0,this.featureName,this.ee)})),this.importAggregator(e,(()=>i.e(296).then(i.bind(i,373))))}}new class extends r{constructor(e){var t;(super(),y.gm)?(this.features={},(0,_.bQ)(this.agentIdentifier,this),this.desiredFeatures=new Set(e.features||[]),this.desiredFeatures.add(R),this.runSoftNavOverSpa=[...this.desiredFeatures].some((e=>e.featureName===n.K7.softNav)),(0,o.j)(this,e,e.loaderType||"agent"),t=this,p(u.cD,(function(e,r,n=!1){if("string"==typeof e){if(["string","number","boolean"].includes(typeof r)||null===r)return m(t,e,r,u.cD,n);(0,l.R)(40,typeof r)}else(0,l.R)(39,typeof e)}),t),function(e){p(u.Dl,(function(t){if("string"==typeof t||null===t)return m(e,"enduser.id",t,u.Dl,!0);(0,l.R)(41,typeof t)}),e)}(this),function(e){p(u.nb,(function(t){if("string"==typeof t||null===t)return m(e,"application.version",t,u.nb,!1);(0,l.R)(42,typeof t)}),e)}(this),function(e){p(u.d3,(function(){e.ee.emit("manual-start-all")}),e)}(this),this.run()):(0,l.R)(21)}get config(){return{info:this.info,init:this.init,loader_config:this.loader_config,runtime:this.runtime}}get api(){return this}run(){try{const e=function(e){const t={};return a.forEach((r=>{t[r]=!!e[r]?.enabled})),t}(this.init),t=[...this.desiredFeatures];t.sort(((e,t)=>n.P3[e.featureName]-n.P3[t.featureName])),t.forEach((t=>{if(!e[t.featureName]&&t.featureName!==n.K7.pageViewEvent)return;if(this.runSoftNavOverSpa&&t.featureName===n.K7.spa)return;if(!this.runSoftNavOverSpa&&t.featureName===n.K7.softNav)return;const r=function(e){switch(e){case n.K7.ajax:return[n.K7.jserrors];case n.K7.sessionTrace:return[n.K7.ajax,n.K7.pageViewEvent];case n.K7.sessionReplay:return[n.K7.sessionTrace];case n.K7.pageViewTiming:return[n.K7.pageViewEvent];default:return[]}}(t.featureName).filter((e=>!(e in this.features)));r.length>0&&(0,l.R)(36,{targetFeature:t.featureName,missingDependencies:r}),this.features[t.featureName]=new t(this)}))}catch(e){(0,l.R)(22,e);for(const e in this.features)this.features[e].abortHandler?.();const t=(0,_.Zm)();delete t.initializedAgents[this.agentIdentifier]?.features,delete this.sharedAggregator;return t.ee.get(this.agentIdentifier).abort(),!1}}}({features:[R,I,O],loaderType:"lite"})})()})();</script>
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name='robots' content='noindex, follow' />
	<style>img:is([sizes="auto" i], [sizes^="auto," i]) { contain-intrinsic-size: 3000px 1500px }</style>
	<script id="cookieyes" type="text/javascript" src="https://cdn-cookieyes.com/client_data/12b7ebb23f206f05ba9b6a37/script.js"></script>
	<!-- This site is optimized with the Yoast SEO plugin v25.5 - https://yoast.com/wordpress/plugins/seo/ -->
	<title>Page not found - Lacuna Fund</title>
	<meta property="og:locale" content="en_US" />
	<meta property="og:title" content="Page not found - Lacuna Fund" />
	<meta property="og:site_name" content="Lacuna Fund" />
	<script type="application/ld+json" class="yoast-schema-graph">{"@context":"https://schema.org","@graph":[{"@type":"WebSite","@id":"https://lacunafund.org/#website","url":"https://lacunafund.org/","name":"Lacuna Fund","description":"Just another Meridian Institute Sites site","potentialAction":[{"@type":"SearchAction","target":{"@type":"EntryPoint","urlTemplate":"https://lacunafund.org/?s={search_term_string}"},"query-input":{"@type":"PropertyValueSpecification","valueRequired":true,"valueName":"search_term_string"}}],"inLanguage":"en-US"}]}</script>
	<!-- / Yoast SEO plugin. -->


<link rel='dns-prefetch' href='//lacunafund.org' />
<link rel='dns-prefetch' href='//www.googletagmanager.com' />
<script>
window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/16.0.1\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/16.0.1\/svg\/","svgExt":".svg","source":{"concatemoji":"https:\/\/lacunafund.org\/wp-includes\/js\/wp-emoji-release.min.js?ver=6.8.2"}};
/*! This file is auto-generated */
!function(s,n){var o,i,e;function c(e){try{var t={supportTests:e,timestamp:(new Date).valueOf()};sessionStorage.setItem(o,JSON.stringify(t))}catch(e){}}function p(e,t,n){e.clearRect(0,0,e.canvas.width,e.canvas.height),e.fillText(t,0,0);var t=new Uint32Array(e.getImageData(0,0,e.canvas.width,e.canvas.height).data),a=(e.clearRect(0,0,e.canvas.width,e.canvas.height),e.fillText(n,0,0),new Uint32Array(e.getImageData(0,0,e.canvas.width,e.canvas.height).data));return t.every(function(e,t){return e===a[t]})}function u(e,t){e.clearRect(0,0,e.canvas.width,e.canvas.height),e.fillText(t,0,0);for(var n=e.getImageData(16,16,1,1),a=0;a<n.data.length;a++)if(0!==n.data[a])return!1;return!0}function f(e,t,n,a){switch(t){case"flag":return n(e,"\ud83c\udff3\ufe0f\u200d\u26a7\ufe0f","\ud83c\udff3\ufe0f\u200b\u26a7\ufe0f")?!1:!n(e,"\ud83c\udde8\ud83c\uddf6","\ud83c\udde8\u200b\ud83c\uddf6")&&!n(e,"\ud83c\udff4\udb40\udc67\udb40\udc62\udb40\udc65\udb40\udc6e\udb40\udc67\udb40\udc7f","\ud83c\udff4\u200b\udb40\udc67\u200b\udb40\udc62\u200b\udb40\udc65\u200b\udb40\udc6e\u200b\udb40\udc67\u200b\udb40\udc7f");case"emoji":return!a(e,"\ud83e\udedf")}return!1}function g(e,t,n,a){var r="undefined"!=typeof WorkerGlobalScope&&self instanceof WorkerGlobalScope?new OffscreenCanvas(300,150):s.createElement("canvas"),o=r.getContext("2d",{willReadFrequently:!0}),i=(o.textBaseline="top",o.font="600 32px Arial",{});return e.forEach(function(e){i[e]=t(o,e,n,a)}),i}function t(e){var t=s.createElement("script");t.src=e,t.defer=!0,s.head.appendChild(t)}"undefined"!=typeof Promise&&(o="wpEmojiSettingsSupports",i=["flag","emoji"],n.supports={everything:!0,everythingExceptFlag:!0},e=new Promise(function(e){s.addEventListener("DOMContentLoaded",e,{once:!0})}),new Promise(function(t){var n=function(){try{var e=JSON.parse(sessionStorage.getItem(o));if("object"==typeof e&&"number"==typeof e.timestamp&&(new Date).valueOf()<e.timestamp+604800&&"object"==typeof e.supportTests)return e.supportTests}catch(e){}return null}();if(!n){if("undefined"!=typeof Worker&&"undefined"!=typeof OffscreenCanvas&&"undefined"!=typeof URL&&URL.createObjectURL&&"undefined"!=typeof Blob)try{var e="postMessage("+g.toString()+"("+[JSON.stringify(i),f.toString(),p.toString(),u.toString()].join(",")+"));",a=new Blob([e],{type:"text/javascript"}),r=new Worker(URL.createObjectURL(a),{name:"wpTestEmojiSupports"});return void(r.onmessage=function(e){c(n=e.data),r.terminate(),t(n)})}catch(e){}c(n=g(i,f,p,u))}t(n)}).then(function(e){for(var t in e)n.supports[t]=e[t],n.supports.everything=n.supports.everything&&n.supports[t],"flag"!==t&&(n.supports.everythingExceptFlag=n.supports.everythingExceptFlag&&n.supports[t]);n.supports.everythingExceptFlag=n.supports.everythingExceptFlag&&!n.supports.flag,n.DOMReady=!1,n.readyCallback=function(){n.DOMReady=!0}}).then(function(){return e}).then(function(){var e;n.supports.everything||(n.readyCallback(),(e=n.source||{}).concatemoji?t(e.concatemoji):e.wpemoji&&e.twemoji&&(t(e.twemoji),t(e.wpemoji)))}))}((window,document),window._wpemojiSettings);
</script>
<style id='wp-emoji-styles-inline-css'>

	img.wp-smiley, img.emoji {
		display: inline !important;
		border: none !important;
		box-shadow: none !important;
		height: 1em !important;
		width: 1em !important;
		margin: 0 0.07em !important;
		vertical-align: -0.1em !important;
		background: none !important;
		padding: 0 !important;
	}
</style>
<style id='safe-svg-svg-icon-style-inline-css'>
.safe-svg-cover{text-align:center}.safe-svg-cover .safe-svg-inside{display:inline-block;max-width:100%}.safe-svg-cover svg{fill:currentColor;height:100%;max-height:100%;max-width:100%;width:100%}

</style>
<link rel='stylesheet' id='wpsm_counter_pro-font-awesome-front-css' href='https://lacunafund.org/wp-content/plugins/counter-number-pro/assets/css/font-awesome/css/font-awesome.min.css?ver=6.8.2' media='all' />
<link rel='stylesheet' id='wpsm_counter_pro_bootstrap-front-css' href='https://lacunafund.org/wp-content/plugins/counter-number-pro/assets/css/bootstrap-front.css?ver=6.8.2' media='all' />
<link rel='stylesheet' id='wpsm_counter_pro_column-css' href='https://lacunafund.org/wp-content/plugins/counter-number-pro/assets/css/counter-column.css?ver=6.8.2' media='all' />
<link rel='stylesheet' id='SFSImainCss-css' href='https://lacunafund.org/wp-content/plugins/ultimate-social-media-icons/css/sfsi-style.css?ver=2.9.5' media='all' />
<link rel='stylesheet' id='wpfront-notification-bar-css' href='https://lacunafund.org/wp-content/plugins/wpfront-notification-bar/css/wpfront-notification-bar.min.css?ver=3.5.1.05102' media='all' />
<link rel='stylesheet' id='app/0-css' href='https://lacunafund.org/wp-content/themes/meridian-microsite-theme/public/css/app.0395d5.css' media='all' />
<script src="https://lacunafund.org/wp-includes/js/jquery/jquery.min.js?ver=3.7.1" id="jquery-core-js"></script>
<script src="https://lacunafund.org/wp-includes/js/jquery/jquery-migrate.min.js?ver=3.4.1" id="jquery-migrate-js"></script>
<script src="https://lacunafund.org/wp-content/plugins/wpfront-notification-bar/jquery-plugins/js-cookie.min.js?ver=2.2.1" id="js-cookie-js"></script>
<script src="https://lacunafund.org/wp-content/plugins/wpfront-notification-bar/js/wpfront-notification-bar.min.js?ver=3.5.1.05102" id="wpfront-notification-bar-js"></script>
<link rel="https://api.w.org/" href="https://lacunafund.org/wp-json/" /><link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://lacunafund.org/xmlrpc.php?rsd" />
<meta name="generator" content="WordPress 6.8.2" />
<meta name="generator" content="Site Kit by Google 1.157.0" /><meta name="generator" content="WPML ver:4.7.6 stt:1,4,2;" />
<script type="text/javascript" src="//lacunafund.org/?wordfence_syncAttackData=1753804549.1339" async></script>
        <style type="text/css">
        :root {
          --primary-color: #005a7c;
          --action-color: #2cb34a;
          --dark-line-color: #ffd600;
          --light-line-color: #a6afb7;
          --global-font-family: Mark Pro;
          --headings-font-family: Mark Pro;
          --font-primary-color: #21384a;
        }
        </style>
        
        <!-- Google Analytics -->
        <script>
            (function(i, s, o, g, r, a, m) {
                i['GoogleAnalyticsObject'] = r;
                i[r] = i[r] || function() {
                (i[r].q = i[r].q || []).push(arguments)
                }, i[r].l = 1 * new Date();
                a = s.createElement(o),
                m = s.getElementsByTagName(o)[0];
                a.async = 1;
                a.src = g;
                m.parentNode.insertBefore(a, m)
            })(window, document, 'script', 'https://www.google-analytics.com/analytics.js', 'ga');

            ga('create', 'UA-166304398-1', 'auto');
            ga('send', 'pageview');
        </script>
        <!-- End Google Analytics -->
        
<!-- Google Tag Manager snippet added by Site Kit -->
<script>
			( function( w, d, s, l, i ) {
				w[l] = w[l] || [];
				w[l].push( {'gtm.start': new Date().getTime(), event: 'gtm.js'} );
				var f = d.getElementsByTagName( s )[0],
					j = d.createElement( s ), dl = l != 'dataLayer' ? '&l=' + l : '';
				j.async = true;
				j.src = 'https://www.googletagmanager.com/gtm.js?id=' + i + dl;
				f.parentNode.insertBefore( j, f );
			} )( window, document, 'script', 'dataLayer', 'GTM-T68C424' );
			
</script>

<!-- End Google Tag Manager snippet added by Site Kit -->
<link rel="icon" href="https://lacunafund.org/wp-content/uploads/sites/11/2020/07/cropped-Small-LacunaFund-Avatar-4C-WhiteBG-1-32x32.png" sizes="32x32" />
<link rel="icon" href="https://lacunafund.org/wp-content/uploads/sites/11/2020/07/cropped-Small-LacunaFund-Avatar-4C-WhiteBG-1-192x192.png" sizes="192x192" />
<link rel="apple-touch-icon" href="https://lacunafund.org/wp-content/uploads/sites/11/2020/07/cropped-Small-LacunaFund-Avatar-4C-WhiteBG-1-180x180.png" />
<meta name="msapplication-TileImage" content="https://lacunafund.org/wp-content/uploads/sites/11/2020/07/cropped-Small-LacunaFund-Avatar-4C-WhiteBG-1-270x270.png" />
  </head>

  <body class="error404 wp-embed-responsive wp-theme-meridian-microsite-theme sfsi_actvite_theme_default">
    		<!-- Google Tag Manager (noscript) snippet added by Site Kit -->
		<noscript>
			<iframe src="https://www.googletagmanager.com/ns.html?id=GTM-T68C424" height="0" width="0" style="display:none;visibility:hidden"></iframe>
		</noscript>
		<!-- End Google Tag Manager (noscript) snippet added by Site Kit -->
		                <style type="text/css">
                #wpfront-notification-bar, #wpfront-notification-bar-editor            {
            background: #fbb161;
            background: -moz-linear-gradient(top, #fbb161 0%, #fbb161 100%);
            background: -webkit-gradient(linear, left top, left bottom, color-stop(0%,#fbb161), color-stop(100%,#fbb161));
            background: -webkit-linear-gradient(top, #fbb161 0%,#fbb161 100%);
            background: -o-linear-gradient(top, #fbb161 0%,#fbb161 100%);
            background: -ms-linear-gradient(top, #fbb161 0%,#fbb161 100%);
            background: linear-gradient(to bottom, #fbb161 0%, #fbb161 100%);
            filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#fbb161', endColorstr='#fbb161',GradientType=0 );
            background-repeat: no-repeat;
                        }
            #wpfront-notification-bar div.wpfront-message, #wpfront-notification-bar-editor.wpfront-message            {
            color: #21384a;
                        }
            #wpfront-notification-bar a.wpfront-button, #wpfront-notification-bar-editor a.wpfront-button            {
            background: #00b7ea;
            background: -moz-linear-gradient(top, #00b7ea 0%, #009ec3 100%);
            background: -webkit-gradient(linear, left top, left bottom, color-stop(0%,#00b7ea), color-stop(100%,#009ec3));
            background: -webkit-linear-gradient(top, #00b7ea 0%,#009ec3 100%);
            background: -o-linear-gradient(top, #00b7ea 0%,#009ec3 100%);
            background: -ms-linear-gradient(top, #00b7ea 0%,#009ec3 100%);
            background: linear-gradient(to bottom, #00b7ea 0%, #009ec3 100%);
            filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#00b7ea', endColorstr='#009ec3',GradientType=0 );

            background-repeat: no-repeat;
            color: #ffffff;
            }
            #wpfront-notification-bar-open-button            {
            background-color: #00b7ea;
            right: 10px;
                        }
            #wpfront-notification-bar-open-button.top                {
                background-image: url(https://lacunafund.org/wp-content/plugins/wpfront-notification-bar/images/arrow_down.png);
                }

                #wpfront-notification-bar-open-button.bottom                {
                background-image: url(https://lacunafund.org/wp-content/plugins/wpfront-notification-bar/images/arrow_up.png);
                }
                #wpfront-notification-bar-table, .wpfront-notification-bar tbody, .wpfront-notification-bar tr            {
                        }
            #wpfront-notification-bar div.wpfront-close            {
            border: 1px solid #fbb161;
            background-color: #fbb161;
            color: #21384a;
            }
            #wpfront-notification-bar div.wpfront-close:hover            {
            border: 1px solid #fbb161;
            background-color: #fbb161;
            }
             #wpfront-notification-bar-spacer { display:block; }                </style>
                            <div id="wpfront-notification-bar-spacer" class="wpfront-notification-bar-spacer  hidden">
                <div id="wpfront-notification-bar-open-button" aria-label="reopen" role="button" class="wpfront-notification-bar-open-button hidden top wpfront-bottom-shadow"></div>
                <div id="wpfront-notification-bar" class="wpfront-notification-bar wpfront-fixed top ">
                                            <div aria-label="close" class="wpfront-close">X</div>
                                         
                            <table id="wpfront-notification-bar-table" border="0" cellspacing="0" cellpadding="0" role="presentation">                        
                                <tr>
                                    <td>
                                     
                                    <div class="wpfront-message wpfront-div">
                                        <p><span class="TextRun  BCX8 SCXO218366053" lang="EN-US" xml:lang="EN-US" data-contrast="auto"><span class="NormalTextRun  BCX8 SCXO218366053"><strong>Lacuna Fund Community:</strong> </span></span><a href="http://merid.org"><span class="TextRun  BCX8 SCXO218366053" lang="EN-US" xml:lang="EN-US" data-contrast="none"><span class="NormalTextRun  BCX8 SCXO218366053">Meridian Institute</span></span></a><span class="TextRun  BCX8 SCXO218366053" lang="EN-US" xml:lang="EN-US" data-contrast="auto"><span class="NormalTextRun  BCX8 SCXO218366053">, who operates as</span></span><span class="TextRun  BCX8 SCXO218366053" lang="EN-US" xml:lang="EN-US" data-contrast="auto"><span class="NormalTextRun  BCX8 SCXO218366053"> </span></span><span class="TextRun  BCX8 SCXO218366053" lang="EN-US" xml:lang="EN-US" data-contrast="none"><span class="NormalTextRun  BCX8 SCXO218366053">Lacuna Fund</span></span><span class="TextRun  BCX8 SCXO218366053" lang="EN-US" xml:lang="EN-US" data-contrast="auto"><span class="NormalTextRun  BCX8 SCXO218366053">'s Secretariat, announced in May that it will begin winding down operations, including transferring some projects to other institutions. Please stay tuned for updates. </span></span><a class="HyperlinkV2  BCX8 SCXO218366053" href="https://merid.org/about/newsroom/meridian-institute-will-suspend-operations/" target="_blank" rel="noreferrer noopener"><span class="TextRun  BCX8 SCXO218366053" lang="EN-US" xml:lang="EN-US" data-contrast="auto"><span class="NormalTextRun  BCX8 SCXO218366053">Read the announcement</span></span></a><span class="TextRun  BCX8 SCXO218366053" lang="EN-US" xml:lang="EN-US" data-contrast="auto"><span class="NormalTextRun  BCX8 SCXO218366053">.</span></span><span class="EOP  BCX8 SCXO218366053"> </span></p>                                    </div>
                                                                                                       
                                    </td>
                                </tr>              
                            </table>
                            
                                    </div>
            </div>
            
            <script type="text/javascript">
                function __load_wpfront_notification_bar() {
                    if (typeof wpfront_notification_bar === "function") {
                        wpfront_notification_bar({"position":1,"height":0,"fixed_position":false,"animate_delay":0.5,"close_button":true,"button_action_close_bar":true,"auto_close_after":0,"display_after":2,"is_admin_bar_showing":false,"display_open_button":false,"keep_closed":true,"keep_closed_for":0,"position_offset":0,"display_scroll":false,"display_scroll_offset":50,"keep_closed_cookie":"wpfront-notification-bar-keep-closed","log":false,"id_suffix":"","log_prefix":"[WPFront Notification Bar]","theme_sticky_selector":"","set_max_views":false,"max_views":0,"max_views_for":0,"max_views_cookie":"wpfront-notification-bar-max-views"});
                    } else {
                                    setTimeout(__load_wpfront_notification_bar, 100);
                    }
                }
                __load_wpfront_notification_bar();
            </script>
                
    <div id="app">
      <a class="sr-only focus:not-sr-only" href="#main">
  Skip to content
</a>

<header class="js-nav at-top banner">
  <div class="banner__bg">
    <div class="container banner__content">
              <a class="logo-full" href="https://lacunafund.org/">
                      <img src="https://lacunafund.org/wp-content/uploads/sites/11/2023/09/RESIZE_2_LacunaFund-Alt2-Tag-1.png" alt="" class="logo">
                  </a>
      
      <nav class="nav-primary flex-grow-1 mobile-menu-hide">
                  <div class="menu-primary-container"><ul id="menu-primary" class="nav"><li id="menu-item-51" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-51"><a href="https://lacunafund.org/about/">About</a>
<ul class="sub-menu">
	<li id="menu-item-28" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-28"><a href="https://lacunafund.org/governance/">Governance</a>
	<ul class="sub-menu">
		<li id="menu-item-52" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-52"><a href="https://lacunafund.org/steering-committee/">Steering Committee</a></li>
		<li id="menu-item-9179" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-9179"><a href="https://lacunafund.org/technical-advisory-panels/">Technical Advisory Panels (TAPs)</a></li>
		<li id="menu-item-47" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-47"><a href="https://lacunafund.org/funders/">Funders</a></li>
	</ul>
</li>
</ul>
</li>
<li id="menu-item-3762" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-3762"><a href="https://lacunafund.org/datasets/">Datasets</a>
<ul class="sub-menu">
	<li id="menu-item-6034" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-6034"><a href="https://lacunafund.org/datasets/agriculture/">Agriculture</a></li>
	<li id="menu-item-6035" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-6035"><a href="https://lacunafund.org/datasets/language/">Language</a></li>
	<li id="menu-item-10405" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-10405"><a href="https://lacunafund.org/datasets/health/">Health</a></li>
	<li id="menu-item-12591" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-12591"><a href="https://lacunafund.org/datasets/climate/">Climate</a></li>
</ul>
</li>
<li id="menu-item-48" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-48"><a href="https://lacunafund.org/apply/">Apply</a>
<ul class="sub-menu">
	<li id="menu-item-186" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-186"><a href="https://lacunafund.org/agriculture/">Agriculture</a></li>
	<li id="menu-item-5077" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5077"><a href="https://lacunafund.org/climate/">Climate</a></li>
	<li id="menu-item-185" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-185"><a href="https://lacunafund.org/health/">Health</a></li>
	<li id="menu-item-184" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-184"><a href="https://lacunafund.org/language/">Language</a></li>
</ul>
</li>
<li id="menu-item-5857" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-5857"><a href="https://lacunafund.org/resources/">Resources</a>
<ul class="sub-menu">
	<li id="menu-item-11098" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-11098"><a href="https://lacunafund.org/resources/">General Resources</a></li>
	<li id="menu-item-10977" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-10977"><a href="https://lacunafund.org/agriculture-resources/">Agriculture Resources</a></li>
	<li id="menu-item-10980" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-10980"><a href="https://lacunafund.org/language-resources/">Language Resources</a></li>
	<li id="menu-item-8992" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-8992"><a href="https://lacunafund.org/health-resources/">Health Resources</a></li>
	<li id="menu-item-8882" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-8882"><a href="https://lacunafund.org/climate-resources/">Climate Resources</a></li>
</ul>
</li>
</ul></div>
              </nav>

      <div class="language-switcher language-switcher--desktop"><div class="language-switcher__current-lang">English</div><ul class="language-switcher__list"><li class="language-switcher__list-item"><a href="https://lacunafund.org/fr/">Français</a></li><li class="language-switcher__list-item"><a href="https://lacunafund.org/es/">Español</a></li></ul></div>

              <div class="align-middle mobile-menu-hide">
          <a href="https://lacunafund.org/news/" class="btn btn--pill btn--ghost"
             target="_self" >News</a>
        </div>
      
                        <button class="button--unstyled icon icon-search toggle-search ml-4 js-search-toggle mobile-menu-hide"
            data-target="#search-modal"></button>
              

      <button class="button--unstyled btn--menu ml-auto js-menu-toggle desktop-menu-hide position-relative"
        data-target="#mobile-menu">
        <span class="btn--menu__line"></span>
        <span class="btn--menu__line"></span>
        <span class="btn--menu__line"></span>
      </button>
    </div>

    <div id="search-modal" class="position-relative modal-search mobile-menu-hide d-flex align-items-center">
      <div class="container">
        <form role="search" method="get" class="search-form d-flex" action="https://lacunafund.org/">
  <div class="flex-grow-1">
    <label>
      <span class="screen-reader-text">Search for:</span>
      <input type="text" class="search-form__input search-field" placeholder="Search..." value=""
        name="s" title="Search for:" />
    </label>
  </div>
  <div class="d-flex">
    <button type="submit"
      class="search-form__input button--unstyled btn-submit icon icon-arrow">Search</button>
  </div>
</form>
      </div>
    </div>

  </div>

</header>

<nav id="mobile-menu" class="modal-nav position-fixed w-100 h-100 bg-white">
  <div class="container">
  <nav class="nav-mobile">
          <div class="menu-primary-container"><ul id="menu-primary-1" class="nav"><li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-51"><a href="https://lacunafund.org/about/">About</a>
<button class='js-mobile-menu menu__btn button--unstyled icon icon-chevron-down' data-target='#submenu-0'></button><div id='submenu-0'  class="sub-menu js-submenu"><ul class='nav'>
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-28"><a href="https://lacunafund.org/governance/">Governance</a>
	<button class='js-mobile-menu menu__btn button--unstyled icon icon-chevron-down' data-target='#submenu-1'></button><div id='submenu-1'  class="sub-menu js-submenu"><ul class='nav'>
		<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-52"><a href="https://lacunafund.org/steering-committee/">Steering Committee</a></li>
		<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-9179"><a href="https://lacunafund.org/technical-advisory-panels/">Technical Advisory Panels (TAPs)</a></li>
		<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-47"><a href="https://lacunafund.org/funders/">Funders</a></li>
	
      </ul>
    </div>
</li>

      </ul>
    </div>
</li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-3762"><a href="https://lacunafund.org/datasets/">Datasets</a>
<button class='js-mobile-menu menu__btn button--unstyled icon icon-chevron-down' data-target='#submenu-0'></button><div id='submenu-0'  class="sub-menu js-submenu"><ul class='nav'>
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-6034"><a href="https://lacunafund.org/datasets/agriculture/">Agriculture</a></li>
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-6035"><a href="https://lacunafund.org/datasets/language/">Language</a></li>
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-10405"><a href="https://lacunafund.org/datasets/health/">Health</a></li>
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-12591"><a href="https://lacunafund.org/datasets/climate/">Climate</a></li>

      </ul>
    </div>
</li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-48"><a href="https://lacunafund.org/apply/">Apply</a>
<button class='js-mobile-menu menu__btn button--unstyled icon icon-chevron-down' data-target='#submenu-0'></button><div id='submenu-0'  class="sub-menu js-submenu"><ul class='nav'>
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-186"><a href="https://lacunafund.org/agriculture/">Agriculture</a></li>
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5077"><a href="https://lacunafund.org/climate/">Climate</a></li>
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-185"><a href="https://lacunafund.org/health/">Health</a></li>
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-184"><a href="https://lacunafund.org/language/">Language</a></li>

      </ul>
    </div>
</li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-5857"><a href="https://lacunafund.org/resources/">Resources</a>
<button class='js-mobile-menu menu__btn button--unstyled icon icon-chevron-down' data-target='#submenu-0'></button><div id='submenu-0'  class="sub-menu js-submenu"><ul class='nav'>
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-11098"><a href="https://lacunafund.org/resources/">General Resources</a></li>
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-10977"><a href="https://lacunafund.org/agriculture-resources/">Agriculture Resources</a></li>
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-10980"><a href="https://lacunafund.org/language-resources/">Language Resources</a></li>
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-8992"><a href="https://lacunafund.org/health-resources/">Health Resources</a></li>
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-8882"><a href="https://lacunafund.org/climate-resources/">Climate Resources</a></li>

      </ul>
    </div>
</li>
</ul></div>
      </nav>

  <div class="language-switcher language-switcher--desktop"><div class="language-switcher__current-lang">English</div><ul class="language-switcher__list"><li class="language-switcher__list-item"><a href="https://lacunafund.org/fr/">Français</a></li><li class="language-switcher__list-item"><a href="https://lacunafund.org/es/">Español</a></li></ul></div>

  <div class="modal-nav__footer">
    <div class="align-middle d-flex mt-3">
              <a href="https://lacunafund.org/news/" class="btn btn--pill btn--ghost"
           target="_self" >News</a>
      
      <button class="button--unstyled icon icon-search toggle-search ml-4 js-search-toggle ml-auto"
        data-target="#search-modal-mobile"></button>
    </div>

    <div id="search-modal-mobile" class="position-relative modal-search mt-4">
      <form role="search" method="get" class="search-form d-flex" action="https://lacunafund.org/">
  <div class="flex-grow-1">
    <label>
      <span class="screen-reader-text">Search for:</span>
      <input type="text" class="search-form__input search-field" placeholder="Search..." value=""
        name="s" title="Search for:" />
    </label>
  </div>
  <div class="d-flex">
    <button type="submit"
      class="search-form__input button--unstyled btn-submit icon icon-arrow">Search</button>
  </div>
</form>
    </div>
  </div>

</div>
</nav>

<div class="wrap" role="document">
  <div class="content" id="content">
    <main class="main position-relative">
                <section class="hero--small position-relative mb-6">

    <div class="hero__triangle d-block svg-h-auto w-100" aria-hidden="true">
      <?xml version="1.0" encoding="utf-8"?>
<!-- Generator: Adobe Illustrator 23.0.2, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->
<svg aria-hidden="true" class="fill-current" version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 viewBox="0 0 1280 510" enable-background="new 0 0 1280 510" xml:space="preserve">
<title>triangle-white</title>
<polygon fill="#FFFFFF" points="1280.5,637.4 0.5,637.4 0.5,479.4 1280.5,158.4 "/>
<path fill="none" stroke="#A6AFB7" stroke-width="2" d="M0,509l1281-322"/>
</svg>    </div>

    <div class="container text-white">
      <div class="row">
        <div class="col-sm-12 col-md-8 col-lg-7">

          <h1>The page you're looking for cannot be found.</h1>

          <p>The link you followed may be broken, or the page <br> may have been moved or removed.</p>

        </div>
      </div>
    </div>


  </section>
          </main>

    <div id="light-window">


  
  


</div>

  </div>
</div>

<footer class="content-info text-white position-relative overflow-hidden">
  <div class="light-line position-absolute top-0 left-0 w-100 h-auto svg-h-auto mt-5" aria-hidden="true">
    <?xml version="1.0" encoding="UTF-8"?>
<svg aria-hidden="true" class="fill-current" width="1281px" height="114px" viewBox="0 0 1281 114" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
    <!-- Generator: Sketch 53.2 (72643) - https://sketchapp.com -->
    <title>Stroke 1 Copy 3</title>
    <desc>Created with Sketch.</desc>
    <g id="Symbols" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
        <g id="Footer" transform="translate(0.000000, -53.000000)" stroke="#A6AFB7" stroke-width="2">
            <path d="M1280,166 L0.939432842,54.390854" id="Stroke-1-Copy-3"></path>
        </g>
    </g>
</svg>  </div>

  <div class="container">
          <div class="row footer__main">
        <div class="col">
                      <div class="footer__form position-relative z-index-2">
              <noscript class="ninja-forms-noscript-message">
	Notice: JavaScript is required for this content.</noscript>
<div id="nf-form-4-cont" class="nf-form-cont" aria-live="polite" aria-labelledby="nf-form-title-4" aria-describedby="nf-form-errors-4" role="form">

    <div class="nf-loading-spinner"></div>

</div>
        <!-- That data is being printed as a workaround to page builders reordering the order of the scripts loaded-->
        <script>var formDisplay=1;var nfForms=nfForms||[];var form=[];form.id='4';form.settings={"objectType":"Form Setting","editActive":true,"title":"Newsletter","show_title":1,"allow_public_link":0,"embed_form":"","clear_complete":1,"hide_complete":1,"default_label_pos":"above","wrapper_class":"","element_class":"","key":"","add_submit":0,"currency":"","unique_field_error":"A form with this value has already been submitted.","logged_in":false,"not_logged_in_msg":"","sub_limit_msg":"The form has reached its submission limit.","calculations":[],"formContentData":["firstname_1593655010370","lastname_1593655011927","email_1593655026643","by_entering_your_email_address_you_agree_to_receive_lacuna_fund_notifications_of_funding_opportunities_and_other_updates_in_accordance_with_our_less_than_strong_greater_than_less_than_a_href_privacy-policy_greater_than_privacy_policy_less_than_a_greater_than_less_than_strong_greater_than_1594332676930","submit_1593655051354"],"changeEmailErrorMsg":"Please enter a valid email address!","changeDateErrorMsg":"Please enter a valid date!","confirmFieldErrorMsg":"These fields must match!","fieldNumberNumMinError":"Number Min Error","fieldNumberNumMaxError":"Number Max Error","fieldNumberIncrementBy":"Please increment by ","formErrorsCorrectErrors":"Please correct errors before submitting this form.","validateRequiredField":"This is a required field.","honeypotHoneypotError":"Honeypot Error","fieldsMarkedRequired":"Fields marked with an <span class=\"ninja-forms-req-symbol\">*<\/span> are required","drawerDisabled":false,"ninjaForms":"Ninja Forms","fieldTextareaRTEInsertLink":"Insert Link","fieldTextareaRTEInsertMedia":"Insert Media","fieldTextareaRTESelectAFile":"Select a file","formHoneypot":"If you are a human seeing this field, please leave it empty.","fileUploadOldCodeFileUploadInProgress":"File Upload in Progress.","fileUploadOldCodeFileUpload":"FILE UPLOAD","currencySymbol":"&#36;","thousands_sep":",","decimal_point":".","siteLocale":"en_US","dateFormat":"m\/d\/Y","startOfWeek":"1","of":"of","previousMonth":"Previous Month","nextMonth":"Next Month","months":["January","February","March","April","May","June","July","August","September","October","November","December"],"monthsShort":["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"],"weekdays":["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"],"weekdaysShort":["Sun","Mon","Tue","Wed","Thu","Fri","Sat"],"weekdaysMin":["Su","Mo","Tu","We","Th","Fr","Sa"],"recaptchaConsentMissing":"reCaptcha validation couldn&#039;t load.","recaptchaMissingCookie":"reCaptcha v3 validation couldn&#039;t load the cookie needed to submit the form.","recaptchaConsentEvent":"Accept reCaptcha cookies before sending the form.","currency_symbol":"","beforeForm":"","beforeFields":"","afterFields":"","afterForm":""};form.fields=[{"objectType":"Field","objectDomain":"fields","editActive":false,"order":999,"type":"firstname","label":"First Name","key":"firstname_1593655010370","label_pos":"hidden","required":1,"default":"","placeholder":"First Name","container_class":"","element_class":"","admin_label":"","help_text":"","custom_name_attribute":"fname","personally_identifiable":1,"value":"","drawerDisabled":false,"id":13,"beforeField":"","afterField":"","parentType":"firstname","element_templates":["firstname","input"],"old_classname":"","wrap_template":"wrap"},{"objectType":"Field","objectDomain":"fields","editActive":false,"order":999,"type":"lastname","label":"Last Name","key":"lastname_1593655011927","label_pos":"hidden","required":1,"default":"","placeholder":"Last Name","container_class":"","element_class":"","admin_label":"","help_text":"","custom_name_attribute":"lname","personally_identifiable":1,"value":"","id":14,"beforeField":"","afterField":"","parentType":"lastname","element_templates":["lastname","input"],"old_classname":"","wrap_template":"wrap"},{"objectType":"Field","objectDomain":"fields","editActive":false,"order":999,"type":"email","label":"Email","key":"email_1593655026643","label_pos":"hidden","required":1,"default":"","placeholder":"Email Address","container_class":"","element_class":"","admin_label":"","help_text":"","custom_name_attribute":"email","personally_identifiable":1,"value":"","drawerDisabled":false,"id":15,"beforeField":"","afterField":"","parentType":"email","element_templates":["email","input"],"old_classname":"","wrap_template":"wrap"},{"objectType":"Field","objectDomain":"fields","editActive":false,"order":999,"type":"checkbox","label":"By entering your email address, you agree to receive Lacuna Fund notifications of funding opportunities and other updates in accordance with our <strong><a href=\"\/privacy-policy\">Privacy Policy<\/a><\/strong>","key":"by_entering_your_email_address_you_agree_to_receive_lacuna_fund_notifications_of_funding_opportunities_and_other_updates_in_accordance_with_our_less_than_strong_greater_than_less_than_a_href_privacy-policy_greater_than_privacy_policy_less_than_a_greater_than_less_than_strong_greater_than_1594332676930","label_pos":"right","required":1,"container_class":"mc_optin","element_class":"","manual_key":false,"admin_label":"","help_text":"","default_value":"unchecked","checked_value":"Checked","unchecked_value":"Unchecked","checked_calc_value":"","unchecked_calc_value":"","drawerDisabled":false,"id":16,"beforeField":"","afterField":"","value":"","parentType":"checkbox","element_templates":["checkbox","input"],"old_classname":"","wrap_template":"wrap"},{"objectType":"Field","objectDomain":"fields","editActive":false,"order":999,"type":"submit","label":"Submit","processing_label":"Processing","container_class":"","element_class":"","key":"submit_1593655051354","drawerDisabled":false,"id":17,"beforeField":"","afterField":"","value":"","label_pos":"above","parentType":"textbox","element_templates":["submit","button","input"],"old_classname":"","wrap_template":"wrap-no-label"}];nfForms.push(form);</script>
        

                              <p>Sign up to receive notifications of funding opportunities and other updates.</p>

                          </div>
                  </div>
      </div>
    
          <div class="row row--grid position-relative z-index-2">
                  <div class="col-9  col-md-3 ">
            
              <div class="logos">
                                                                      <a class="d-block footer__logo" href="http://merid.org"
                    target="">
                    <img width="160" height="58" src="https://lacunafund.org/wp-content/uploads/sites/11/2020/07/MI_Logo_R_RGB_White-160x58.png" class="footer_logo" alt="" decoding="async" loading="lazy" srcset="https://lacunafund.org/wp-content/uploads/sites/11/2020/07/MI_Logo_R_RGB_White-160x58.png 160w, https://lacunafund.org/wp-content/uploads/sites/11/2020/07/MI_Logo_R_RGB_White-300x109.png 300w, https://lacunafund.org/wp-content/uploads/sites/11/2020/07/MI_Logo_R_RGB_White-1024x371.png 1024w, https://lacunafund.org/wp-content/uploads/sites/11/2020/07/MI_Logo_R_RGB_White-768x279.png 768w, https://lacunafund.org/wp-content/uploads/sites/11/2020/07/MI_Logo_R_RGB_White-1536x557.png 1536w, https://lacunafund.org/wp-content/uploads/sites/11/2020/07/MI_Logo_R_RGB_White-2048x743.png 2048w, https://lacunafund.org/wp-content/uploads/sites/11/2020/07/MI_Logo_R_RGB_White-1920x696.png 1920w, https://lacunafund.org/wp-content/uploads/sites/11/2020/07/MI_Logo_R_RGB_White-1280x464.png 1280w, https://lacunafund.org/wp-content/uploads/sites/11/2020/07/MI_Logo_R_RGB_White-640x232.png 640w, https://lacunafund.org/wp-content/uploads/sites/11/2020/07/MI_Logo_R_RGB_White-810x294.png 810w" sizes="auto, (max-width: 160px) 100vw, 160px" />
                  </a>
                              </div>
                                      <div class="accompanying_text">
                <h4></h4>
<h5></h5>

              </div>
                      </div>
        
                              <div class="col-12  col-md-3 ">
              <h6>Lacuna Fund Secretariat</h6>
              <p>Contact us at: secretariat@lacunafund.org</p>
            </div>
                  
                              <div
              class="col-12 offset-0 offset-md-0  col-md-3 col-lg-2 offset-lg-1 ">
                      <h6>
    Follow us
  </h6>

  <div>
          <a href="http://www.twitter.com/LacunaFund" class="btn-icon btn-icon--white icon icon-twitter mr-2 mb-2"
        target="_blank"></a>
          <a href="http://www.linkedin.com/company/LacunaFund" class="btn-icon btn-icon--white icon icon-linkedin mr-2 mb-2"
        target="_blank"></a>
      </div>
      </div>
    
      </div>
  
  </div>

  <div class="light-line position-absolute right-0 bottom-0 z-index-1" aria-hidden="true">
    <?xml version="1.0" encoding="UTF-8"?>
<svg aria-hidden="true" class="fill-current" width="292px" height="466px" viewBox="0 0 292 466" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
    <!-- Generator: Sketch 53.2 (72643) - https://sketchapp.com -->
    <title>Group</title>
    <desc>Created with Sketch.</desc>
    <g id="Symbols" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
        <g id="Footer" transform="translate(-990.000000, -316.000000)" stroke="#A6AFB7" stroke-width="2">
            <g id="Group" transform="translate(991.000000, 317.000000)">
                <path d="M289.055373,383 L1.98951966e-13,463.293159" id="Stroke-1-Copy-2"></path>
                <path d="M160,462.237823 L289.368447,5.68434189e-14" id="Stroke-3-Copy"></path>
            </g>
        </g>
    </g>
</svg>  </div>
</footer>
    </div>

        <script type="speculationrules">
{"prefetch":[{"source":"document","where":{"and":[{"href_matches":"\/*"},{"not":{"href_matches":["\/wp-*.php","\/wp-admin\/*","\/wp-content\/uploads\/sites\/11\/*","\/wp-content\/*","\/wp-content\/plugins\/*","\/wp-content\/themes\/meridian-microsite-theme\/*","\/*\\?(.+)"]}},{"not":{"selector_matches":"a[rel~=\"nofollow\"]"}},{"not":{"selector_matches":".no-prefetch, .no-prefetch a"}}]},"eagerness":"conservative"}]}
</script>
                <!--facebook like and share js -->
                <div id="fb-root"></div>
                <script>
                    (function(d, s, id) {
                        var js, fjs = d.getElementsByTagName(s)[0];
                        if (d.getElementById(id)) return;
                        js = d.createElement(s);
                        js.id = id;
                        js.src = "https://connect.facebook.net/en_US/sdk.js#xfbml=1&version=v3.2";
                        fjs.parentNode.insertBefore(js, fjs);
                    }(document, 'script', 'facebook-jssdk'));
                </script>
                <script>
window.addEventListener('sfsi_functions_loaded', function() {
    if (typeof sfsi_responsive_toggle == 'function') {
        sfsi_responsive_toggle(0);
        // console.log('sfsi_responsive_toggle');

    }
})
</script>
    <script>
        window.addEventListener('sfsi_functions_loaded', function () {
            if (typeof sfsi_plugin_version == 'function') {
                sfsi_plugin_version(2.77);
            }
        });

        function sfsi_processfurther(ref) {
            var feed_id = '';
            var feedtype = 8;
            var email = jQuery(ref).find('input[name="email"]').val();
            var filter = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
            if ((email != "Enter your email") && (filter.test(email))) {
                if (feedtype == "8") {
                    var url = "https://api.follow.it/subscription-form/" + feed_id + "/" + feedtype;
                    window.open(url, "popupwindow", "scrollbars=yes,width=1080,height=760");
                    return true;
                }
            } else {
                alert("Please enter email address");
                jQuery(ref).find('input[name="email"]').focus();
                return false;
            }
        }
    </script>
    <style type="text/css" aria-selected="true">
        .sfsi_subscribe_Popinner {
             width: 100% !important;

            height: auto !important;

         padding: 18px 0px !important;

            background-color: #ffffff !important;
        }

        .sfsi_subscribe_Popinner form {
            margin: 0 20px !important;
        }

        .sfsi_subscribe_Popinner h5 {
            font-family: Helvetica,Arial,sans-serif !important;

             font-weight: bold !important;   color:#000000 !important; font-size: 16px !important;   text-align:center !important; margin: 0 0 10px !important;
            padding: 0 !important;
        }

        .sfsi_subscription_form_field {
            margin: 5px 0 !important;
            width: 100% !important;
            display: inline-flex;
            display: -webkit-inline-flex;
        }

        .sfsi_subscription_form_field input {
            width: 100% !important;
            padding: 10px 0px !important;
        }

        .sfsi_subscribe_Popinner input[type=email] {
         font-family: Helvetica,Arial,sans-serif !important;   font-style:normal !important;  color: #000000 !important;   font-size:14px !important; text-align: center !important;        }

        .sfsi_subscribe_Popinner input[type=email]::-webkit-input-placeholder {

         font-family: Helvetica,Arial,sans-serif !important;   font-style:normal !important;  color:#000000 !important; font-size: 14px !important;   text-align:center !important;        }

        .sfsi_subscribe_Popinner input[type=email]:-moz-placeholder {
            /* Firefox 18- */
         font-family: Helvetica,Arial,sans-serif !important;   font-style:normal !important;   color:#000000 !important; font-size: 14px !important;   text-align:center !important;
        }

        .sfsi_subscribe_Popinner input[type=email]::-moz-placeholder {
            /* Firefox 19+ */
         font-family: Helvetica,Arial,sans-serif !important;   font-style: normal !important;
              color:#000000 !important; font-size: 14px !important;   text-align:center !important;        }

        .sfsi_subscribe_Popinner input[type=email]:-ms-input-placeholder {

            font-family: Helvetica,Arial,sans-serif !important;  font-style:normal !important;  color: #000000 !important;  font-size:14px !important;
         text-align: center !important;        }

        .sfsi_subscribe_Popinner input[type=submit] {

         font-family: Helvetica,Arial,sans-serif !important;   font-weight: bold !important;   color:#000000 !important; font-size: 16px !important;   text-align:center !important; background-color: #dedede !important;        }

                .sfsi_shortcode_container {
            float: left;
        }

        .sfsi_shortcode_container .norm_row .sfsi_wDiv {
            position: relative !important;
        }

        .sfsi_shortcode_container .sfsi_holders {
            display: none;
        }

            </style>

    <link rel='stylesheet' id='dashicons-css' href='https://lacunafund.org/wp-includes/css/dashicons.min.css?ver=6.8.2' media='all' />
<link rel='stylesheet' id='nf-display-css' href='https://lacunafund.org/wp-content/plugins/ninja-forms/assets/css/display-opinions-light.css?ver=6.8.2' media='all' />
<link rel='stylesheet' id='nf-font-awesome-css' href='https://lacunafund.org/wp-content/plugins/ninja-forms/assets/css/font-awesome.min.css?ver=6.8.2' media='all' />
<script src="https://lacunafund.org/wp-content/plugins/counter-number-pro/assets/js/bootstrap.js?ver=6.8.2" id="wpsm_count_pro_bootstrap-js-front-js"></script>
<script src="https://lacunafund.org/wp-content/plugins/counter-number-pro/assets/js/waypoint.js?ver=6.8.2" id="wpsm-new_count_waypoint-js"></script>
<script src="https://lacunafund.org/wp-content/plugins/counter-number-pro/assets/js/counter_nscript.js?ver=6.8.2" id="wpsm-new_count_script3-js"></script>
<script src="https://lacunafund.org/wp-content/plugins/counter-number-pro/assets/js/jquery.counterup.min.js?ver=6.8.2" id="wpsm-new_count_script2-js"></script>
<script src="https://lacunafund.org/wp-includes/js/jquery/ui/core.min.js?ver=1.13.3" id="jquery-ui-core-js"></script>
<script src="https://lacunafund.org/wp-content/plugins/ultimate-social-media-icons/js/shuffle/modernizr.custom.min.js?ver=6.8.2" id="SFSIjqueryModernizr-js"></script>
<script src="https://lacunafund.org/wp-content/plugins/ultimate-social-media-icons/js/shuffle/jquery.shuffle.min.js?ver=6.8.2" id="SFSIjqueryShuffle-js"></script>
<script src="https://lacunafund.org/wp-content/plugins/ultimate-social-media-icons/js/shuffle/random-shuffle-min.js?ver=6.8.2" id="SFSIjqueryrandom-shuffle-js"></script>
<script id="SFSICustomJs-js-extra">
var sfsi_icon_ajax_object = {"nonce":"8c2b19696a","ajax_url":"https:\/\/lacunafund.org\/wp-admin\/admin-ajax.php","plugin_url":"https:\/\/lacunafund.org\/wp-content\/plugins\/ultimate-social-media-icons\/"};
</script>
<script src="https://lacunafund.org/wp-content/plugins/ultimate-social-media-icons/js/custom.js?ver=2.9.5" id="SFSICustomJs-js"></script>
<script src="https://lacunafund.org/wp-includes/js/dist/vendor/lodash.min.js?ver=4.17.21" id="lodash-js"></script>
<script id="lodash-js-after">
window.lodash = _.noConflict();
</script>
<script id="app/0-js-extra">
var MapFilters = [{"locations":{"AF":"Afghanistan","AX":"Aland Islands","AL":"Albania","DZ":"Algeria","AS":"American Samoa","AD":"Andorra","AO":"Angola","AI":"Anguilla","AQ":"Antarctica","AG":"Antigua and Barbuda","AR":"Argentina","AM":"Armenia","AW":"Aruba","AU":"Australia","AT":"Austria","AZ":"Azerbaijan","BS":"Bahamas","BH":"Bahrain","BD":"Bangladesh","BB":"Barbados","BY":"Belarus","BE":"Belgium","BZ":"Belize","BJ":"Benin","BM":"Bermuda","BT":"Bhutan","BO":"Bolivia","BQ":"Bonaire, Saint Eustatius and Saba","BA":"Bosnia and Herzegovina","BW":"Botswana","BV":"Bouvet Island","BR":"Brazil","IO":"British Indian Ocean Territory","VG":"British Virgin Islands","BN":"Brunei","BG":"Bulgaria","BF":"Burkina Faso","BI":"Burundi","KH":"Cambodia","CM":"Cameroon","CA":"Canada","CV":"Cape Verde","KY":"Cayman Islands","CF":"Central African Republic","TD":"Chad","CL":"Chile","CN":"China","CX":"Christmas Island","CC":"Cocos Islands","CO":"Colombia","KM":"Comoros","CK":"Cook Islands","CR":"Costa Rica","HR":"Croatia","CU":"Cuba","CW":"Curacao","CY":"Cyprus","CZ":"Czech Republic","CD":"Democratic Republic of the Congo","DK":"Denmark","DJ":"Djibouti","DM":"Dominica","DO":"Dominican Republic","TL":"East Timor","EC":"Ecuador","EG":"Egypt","SV":"El Salvador","GQ":"Equatorial Guinea","ER":"Eritrea","EE":"Estonia","ET":"Ethiopia","FK":"Falkland Islands","FO":"Faroe Islands","FJ":"Fiji","FI":"Finland","FR":"France","GF":"French Guiana","PF":"French Polynesia","TF":"French Southern Territories","GA":"Gabon","GM":"Gambia","GE":"Georgia","DE":"Germany","GH":"Ghana","GI":"Gibraltar","GR":"Greece","GL":"Greenland","GD":"Grenada","GP":"Guadeloupe","GU":"Guam","GT":"Guatemala","GG":"Guernsey","GN":"Guinea","GW":"Guinea-Bissau","GY":"Guyana","HT":"Haiti","HM":"Heard Island and McDonald Islands","HN":"Honduras","HK":"Hong Kong","HU":"Hungary","IS":"Iceland","IN":"India","ID":"Indonesia","IR":"Iran","IQ":"Iraq","IE":"Ireland","IM":"Isle of Man","IL":"Israel","IT":"Italy","CI":"Ivory Coast","JM":"Jamaica","JP":"Japan","JE":"Jersey","JO":"Jordan","KZ":"Kazakhstan","KE":"Kenya","KI":"Kiribati","XK":"Kosovo","KW":"Kuwait","KG":"Kyrgyzstan","LA":"Laos","LV":"Latvia","LB":"Lebanon","LS":"Lesotho","LR":"Liberia","LY":"Libya","LI":"Liechtenstein","LT":"Lithuania","LU":"Luxembourg","MO":"Macao","MK":"Macedonia","MG":"Madagascar","MW":"Malawi","MY":"Malaysia","MV":"Maldives","ML":"Mali","MT":"Malta","MH":"Marshall Islands","MQ":"Martinique","MR":"Mauritania","MU":"Mauritius","YT":"Mayotte","MX":"Mexico","FM":"Micronesia","MD":"Moldova","MC":"Monaco","MN":"Mongolia","ME":"Montenegro","MS":"Montserrat","MA":"Morocco","MZ":"Mozambique","MM":"Myanmar","NA":"Namibia","NR":"Nauru","NP":"Nepal","NL":"Netherlands","NC":"New Caledonia","NZ":"New Zealand","NI":"Nicaragua","NE":"Niger","NG":"Nigeria","NU":"Niue","NF":"Norfolk Island","KP":"North Korea","MP":"Northern Mariana Islands","NO":"Norway","OM":"Oman","PK":"Pakistan","PW":"Palau","PS":"Palestinian Territory","PA":"Panama","PG":"Papua New Guinea","PY":"Paraguay","PE":"Peru","PH":"Philippines","PN":"Pitcairn","PL":"Poland","PT":"Portugal","PR":"Puerto Rico","QA":"Qatar","CG":"Republic of the Congo","RE":"Reunion","RO":"Romania","RU":"Russia","RW":"Rwanda","BL":"Saint Barthelemy","SH":"Saint Helena","KN":"Saint Kitts and Nevis","LC":"Saint Lucia","MF":"Saint Martin","PM":"Saint Pierre and Miquelon","VC":"Saint Vincent and the Grenadines","WS":"Samoa","SM":"San Marino","ST":"Sao Tome and Principe","SA":"Saudi Arabia","SN":"Senegal","RS":"Serbia","SC":"Seychelles","SL":"Sierra Leone","SG":"Singapore","SX":"Sint Maarten","SK":"Slovakia","SI":"Slovenia","SB":"Solomon Islands","SO":"Somalia","ZA":"South Africa","GS":"South Georgia and the South Sandwich Islands","KR":"South Korea","SS":"South Sudan","ES":"Spain","LK":"Sri Lanka","SD":"Sudan","SR":"Suriname","SJ":"Svalbard and Jan Mayen","SZ":"Swaziland","SE":"Sweden","CH":"Switzerland","SY":"Syria","TW":"Taiwan","TJ":"Tajikistan","TZ":"Tanzania","TH":"Thailand","TG":"Togo","TK":"Tokelau","TO":"Tonga","TT":"Trinidad and Tobago","TN":"Tunisia","TR":"Turkey","TM":"Turkmenistan","TC":"Turks and Caicos Islands","TV":"Tuvalu","VI":"U.S. Virgin Islands","UG":"Uganda","UA":"Ukraine","AE":"United Arab Emirates","GB":"United Kingdom","US":"United States","UM":"United States Minor Outlying Islands","UY":"Uruguay","UZ":"Uzbekistan","VU":"Vanuatu","VA":"Vatican","VE":"Venezuela","VN":"Vietnam","WF":"Wallis and Futuna","EH":"Western Sahara","YE":"Yemen","ZM":"Zambia","ZW":"Zimbabwe"},"locationLabel":"country","locationMetaKey":"country","locationViewAllLabel":"All Countries"}];
var MapGlobals = {"mapbox_token":"pk.eyJ1IjoibWVyaWRvcmciLCJhIjoiY2p3MDMycW45MDZ1OTQzdGd0ZmoxOWdkZiJ9.gBgL2hmMH-zZeDhppCvrbw","mapbox_style_url":"mapbox:\/\/styles\/meridorg\/cjvzpsfeb1iin1ctdaf4l7sob","api_namespace":"wp-json\/wp\/v2"};
var WPML = {"current_lang":"en"};
</script>
<script id="app/0-js-before">
(()=>{"use strict";var e,r={},o={};function t(e){var a=o[e];if(void 0!==a)return a.exports;var n=o[e]={exports:{}};return r[e].call(n.exports,n,n.exports,t),n.exports}t.m=r,e=[],t.O=(r,o,a,n)=>{if(!o){var l=1/0;for(f=0;f<e.length;f++){for(var[o,a,n]=e[f],i=!0,u=0;u<o.length;u++)(!1&n||l>=n)&&Object.keys(t.O).every((e=>t.O[e](o[u])))?o.splice(u--,1):(i=!1,n<l&&(l=n));if(i){e.splice(f--,1);var s=a();void 0!==s&&(r=s)}}return r}n=n||0;for(var f=e.length;f>0&&e[f-1][2]>n;f--)e[f]=e[f-1];e[f]=[o,a,n]},t.n=e=>{var r=e&&e.__esModule?()=>e.default:()=>e;return t.d(r,{a:r}),r},t.d=(e,r)=>{for(var o in r)t.o(r,o)&&!t.o(e,o)&&Object.defineProperty(e,o,{enumerable:!0,get:r[o]})},t.o=(e,r)=>Object.prototype.hasOwnProperty.call(e,r),t.r=e=>{"undefined"!=typeof Symbol&&Symbol.toStringTag&&Object.defineProperty(e,Symbol.toStringTag,{value:"Module"}),Object.defineProperty(e,"__esModule",{value:!0})},(()=>{var e={666:0};t.O.j=r=>0===e[r];var r=(r,o)=>{var a,n,[l,i,u]=o,s=0;if(l.some((r=>0!==e[r]))){for(a in i)t.o(i,a)&&(t.m[a]=i[a]);if(u)var f=u(t)}for(r&&r(o);s<l.length;s++)n=l[s],t.o(e,n)&&e[n]&&e[n][0](),e[n]=0;return t.O(f)},o=globalThis.webpackChunksage=globalThis.webpackChunksage||[];o.forEach(r.bind(null,0)),o.push=r.bind(null,o.push.bind(o))})()})();
</script>
<script src="https://lacunafund.org/wp-content/themes/meridian-microsite-theme/public/js/575.9ffd3f.js" id="app/0-js"></script>
<script src="https://lacunafund.org/wp-content/themes/meridian-microsite-theme/public/js/145.c7708b.js" id="app/1-js"></script>
<script src="https://lacunafund.org/wp-content/themes/meridian-microsite-theme/public/js/app.8035fa.js" id="app/2-js"></script>
<script src="https://lacunafund.org/wp-includes/js/underscore.min.js?ver=1.13.7" id="underscore-js"></script>
<script src="https://lacunafund.org/wp-includes/js/backbone.min.js?ver=1.6.0" id="backbone-js"></script>
<script src="https://lacunafund.org/wp-content/plugins/ninja-forms/assets/js/min/front-end-deps.js?ver=3.10.4" id="nf-front-end-deps-js"></script>
<script id="nf-front-end-js-extra">
var nfi18n = {"ninjaForms":"Ninja Forms","changeEmailErrorMsg":"Please enter a valid email address!","changeDateErrorMsg":"Please enter a valid date!","confirmFieldErrorMsg":"These fields must match!","fieldNumberNumMinError":"Number Min Error","fieldNumberNumMaxError":"Number Max Error","fieldNumberIncrementBy":"Please increment by ","fieldTextareaRTEInsertLink":"Insert Link","fieldTextareaRTEInsertMedia":"Insert Media","fieldTextareaRTESelectAFile":"Select a file","formErrorsCorrectErrors":"Please correct errors before submitting this form.","formHoneypot":"If you are a human seeing this field, please leave it empty.","validateRequiredField":"This is a required field.","honeypotHoneypotError":"Honeypot Error","fileUploadOldCodeFileUploadInProgress":"File Upload in Progress.","fileUploadOldCodeFileUpload":"FILE UPLOAD","currencySymbol":"$","fieldsMarkedRequired":"Fields marked with an <span class=\"ninja-forms-req-symbol\">*<\/span> are required","thousands_sep":",","decimal_point":".","siteLocale":"en_US","dateFormat":"m\/d\/Y","startOfWeek":"1","of":"of","previousMonth":"Previous Month","nextMonth":"Next Month","months":["January","February","March","April","May","June","July","August","September","October","November","December"],"monthsShort":["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"],"weekdays":["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"],"weekdaysShort":["Sun","Mon","Tue","Wed","Thu","Fri","Sat"],"weekdaysMin":["Su","Mo","Tu","We","Th","Fr","Sa"],"recaptchaConsentMissing":"reCaptcha validation couldn't load.","recaptchaMissingCookie":"reCaptcha v3 validation couldn't load the cookie needed to submit the form.","recaptchaConsentEvent":"Accept reCaptcha cookies before sending the form."};
var nfFrontEnd = {"adminAjax":"https:\/\/lacunafund.org\/wp-admin\/admin-ajax.php","ajaxNonce":"d0e0736a09","requireBaseUrl":"https:\/\/lacunafund.org\/wp-content\/plugins\/ninja-forms\/assets\/js\/","use_merge_tags":{"user":{"address":"address","textbox":"textbox","button":"button","checkbox":"checkbox","city":"city","confirm":"confirm","date":"date","email":"email","firstname":"firstname","html":"html","hidden":"hidden","lastname":"lastname","listcheckbox":"listcheckbox","listcountry":"listcountry","listimage":"listimage","listmultiselect":"listmultiselect","listradio":"listradio","listselect":"listselect","liststate":"liststate","note":"note","number":"number","password":"password","passwordconfirm":"passwordconfirm","product":"product","quantity":"quantity","recaptcha":"recaptcha","recaptcha_v3":"recaptcha_v3","repeater":"repeater","shipping":"shipping","spam":"spam","starrating":"starrating","submit":"submit","terms":"terms","textarea":"textarea","total":"total","unknown":"unknown","zip":"zip","hr":"hr","mailchimp-optin":"mailchimp-optin"},"post":{"address":"address","textbox":"textbox","button":"button","checkbox":"checkbox","city":"city","confirm":"confirm","date":"date","email":"email","firstname":"firstname","html":"html","hidden":"hidden","lastname":"lastname","listcheckbox":"listcheckbox","listcountry":"listcountry","listimage":"listimage","listmultiselect":"listmultiselect","listradio":"listradio","listselect":"listselect","liststate":"liststate","note":"note","number":"number","password":"password","passwordconfirm":"passwordconfirm","product":"product","quantity":"quantity","recaptcha":"recaptcha","recaptcha_v3":"recaptcha_v3","repeater":"repeater","shipping":"shipping","spam":"spam","starrating":"starrating","submit":"submit","terms":"terms","textarea":"textarea","total":"total","unknown":"unknown","zip":"zip","hr":"hr","mailchimp-optin":"mailchimp-optin"},"system":{"address":"address","textbox":"textbox","button":"button","checkbox":"checkbox","city":"city","confirm":"confirm","date":"date","email":"email","firstname":"firstname","html":"html","hidden":"hidden","lastname":"lastname","listcheckbox":"listcheckbox","listcountry":"listcountry","listimage":"listimage","listmultiselect":"listmultiselect","listradio":"listradio","listselect":"listselect","liststate":"liststate","note":"note","number":"number","password":"password","passwordconfirm":"passwordconfirm","product":"product","quantity":"quantity","recaptcha":"recaptcha","recaptcha_v3":"recaptcha_v3","repeater":"repeater","shipping":"shipping","spam":"spam","starrating":"starrating","submit":"submit","terms":"terms","textarea":"textarea","total":"total","unknown":"unknown","zip":"zip","hr":"hr","mailchimp-optin":"mailchimp-optin"},"fields":{"address":"address","textbox":"textbox","button":"button","checkbox":"checkbox","city":"city","confirm":"confirm","date":"date","email":"email","firstname":"firstname","html":"html","hidden":"hidden","lastname":"lastname","listcheckbox":"listcheckbox","listcountry":"listcountry","listimage":"listimage","listmultiselect":"listmultiselect","listradio":"listradio","listselect":"listselect","liststate":"liststate","note":"note","number":"number","password":"password","passwordconfirm":"passwordconfirm","product":"product","quantity":"quantity","recaptcha":"recaptcha","recaptcha_v3":"recaptcha_v3","repeater":"repeater","shipping":"shipping","spam":"spam","starrating":"starrating","submit":"submit","terms":"terms","textarea":"textarea","total":"total","unknown":"unknown","zip":"zip","hr":"hr","mailchimp-optin":"mailchimp-optin"},"calculations":{"html":"html","hidden":"hidden","note":"note","unknown":"unknown"}},"opinionated_styles":"light","filter_esc_status":"false","nf_consent_status_response":[]};
var nfInlineVars = [];
</script>
<script src="https://lacunafund.org/wp-content/plugins/ninja-forms/assets/js/min/front-end.js?ver=3.10.4" id="nf-front-end-js"></script>
<script id="tmpl-nf-layout" type="text/template">
	<span id="nf-form-title-{{{ data.id }}}" class="nf-form-title">
		{{{ ( 1 == data.settings.show_title ) ? '<h' + data.settings.form_title_heading_level + '>' + data.settings.title + '</h' + data.settings.form_title_heading_level + '>' : '' }}}
	</span>
	<div class="nf-form-wrap ninja-forms-form-wrap">
		<div class="nf-response-msg"></div>
		<div class="nf-debug-msg"></div>
		<div class="nf-before-form"></div>
		<div class="nf-form-layout"></div>
		<div class="nf-after-form"></div>
	</div>
</script>

<script id="tmpl-nf-empty" type="text/template">

</script>
<script id="tmpl-nf-before-form" type="text/template">
	{{{ data.beforeForm }}}
</script><script id="tmpl-nf-after-form" type="text/template">
	{{{ data.afterForm }}}
</script><script id="tmpl-nf-before-fields" type="text/template">
    <div class="nf-form-fields-required">{{{ data.renderFieldsMarkedRequired() }}}</div>
    {{{ data.beforeFields }}}
</script><script id="tmpl-nf-after-fields" type="text/template">
    {{{ data.afterFields }}}
    <div id="nf-form-errors-{{{ data.id }}}" class="nf-form-errors" role="alert"></div>
    <div class="nf-form-hp"></div>
</script>
<script id="tmpl-nf-before-field" type="text/template">
    {{{ data.beforeField }}}
</script><script id="tmpl-nf-after-field" type="text/template">
    {{{ data.afterField }}}
</script><script id="tmpl-nf-form-layout" type="text/template">
	<form>
		<div>
			<div class="nf-before-form-content"></div>
			<div class="nf-form-content {{{ data.element_class }}}"></div>
			<div class="nf-after-form-content"></div>
		</div>
	</form>
</script><script id="tmpl-nf-form-hp" type="text/template">
	<label id="nf-label-field-hp-{{{ data.id }}}" for="nf-field-hp-{{{ data.id }}}" aria-hidden="true">
		{{{ nfi18n.formHoneypot }}}
		<input id="nf-field-hp-{{{ data.id }}}" name="nf-field-hp" class="nf-element nf-field-hp" type="text" value="" aria-labelledby="nf-label-field-hp-{{{ data.id }}}" />
	</label>
</script>
<script id="tmpl-nf-field-layout" type="text/template">
    <div id="nf-field-{{{ data.id }}}-container" class="nf-field-container {{{ data.type }}}-container {{{ data.renderContainerClass() }}}">
        <div class="nf-before-field"></div>
        <div class="nf-field"></div>
        <div class="nf-after-field"></div>
    </div>
</script>
<script id="tmpl-nf-field-before" type="text/template">
    {{{ data.beforeField }}}
</script><script id="tmpl-nf-field-after" type="text/template">
    <#
    /*
     * Render our input limit section if that setting exists.
     */
    #>
    <div class="nf-input-limit"></div>
    <#
    /*
     * Render our error section if we have an error.
     */
    #>
    <div id="nf-error-{{{ data.id }}}" class="nf-error-wrap nf-error" role="alert" aria-live="assertive"></div>
    <#
    /*
     * Render any custom HTML after our field.
     */
    #>
    {{{ data.afterField }}}
</script>
<script id="tmpl-nf-field-wrap" type="text/template">
	<div id="nf-field-{{{ data.id }}}-wrap" class="{{{ data.renderWrapClass() }}}" data-field-id="{{{ data.id }}}">
		<#
		/*
		 * This is our main field template. It's called for every field type.
		 * Note that must have ONE top-level, wrapping element. i.e. a div/span/etc that wraps all of the template.
		 */
        #>
		<#
		/*
		 * Render our label.
		 */
        #>
		{{{ data.renderLabel() }}}
		<#
		/*
		 * Render our field element. Uses the template for the field being rendered.
		 */
        #>
		<div class="nf-field-element">{{{ data.renderElement() }}}</div>
		<#
		/*
		 * Render our Description Text.
		 */
        #>
		{{{ data.renderDescText() }}}
	</div>
</script>
<script id="tmpl-nf-field-wrap-no-label" type="text/template">
    <div id="nf-field-{{{ data.id }}}-wrap" class="{{{ data.renderWrapClass() }}}" data-field-id="{{{ data.id }}}">
        <div class="nf-field-label"></div>
        <div class="nf-field-element">{{{ data.renderElement() }}}</div>
        <div class="nf-error-wrap"></div>
    </div>
</script>
<script id="tmpl-nf-field-wrap-no-container" type="text/template">

        {{{ data.renderElement() }}}

        <div class="nf-error-wrap"></div>
</script>
<script id="tmpl-nf-field-label" type="text/template">
	<div class="nf-field-label">
		<# if ( data.type === "listcheckbox" || data.type === "listradio" || data.type === "listimage" || data.type === "date" || data.type === "starrating" ) { #>
			<span id="nf-label-field-{{{ data.id }}}"
				class="nf-label-span {{{ data.renderLabelClasses() }}}">
					{{{ ( data.maybeFilterHTML() === 'true' ) ? _.escape( data.label ) : data.label }}} {{{ ( 'undefined' != typeof data.required && 1 == data.required ) ? '<span class="ninja-forms-req-symbol">*</span>' : '' }}} 
					{{{ data.maybeRenderHelp() }}}
			</span>
		<# } else { #>
			<label for="nf-field-{{{ data.id }}}"
					id="nf-label-field-{{{ data.id }}}"
					class="{{{ data.renderLabelClasses() }}}">
						{{{ ( data.maybeFilterHTML() === 'true' ) ? _.escape( data.label ) : data.label }}} {{{ ( 'undefined' != typeof data.required && 1 == data.required ) ? '<span class="ninja-forms-req-symbol">*</span>' : '' }}} 
						{{{ data.maybeRenderHelp() }}}
			</label>
		<# } #>
	</div>
</script><script id="tmpl-nf-field-error" type="text/template">
	<div class="nf-error-msg nf-error-{{{ data.id }}}" aria-live="assertive">{{{ data.msg }}}</div>
</script><script id="tmpl-nf-form-error" type="text/template">
	<div class="nf-error-msg nf-error-{{{ data.id }}}">{{{ data.msg }}}</div>
</script><script id="tmpl-nf-field-input-limit" type="text/template">
    {{{ data.currentCount() }}} {{{ nfi18n.of }}} {{{ data.input_limit }}} {{{ data.input_limit_msg }}}
</script><script id="tmpl-nf-field-null" type="text/template">
</script><script id="tmpl-nf-field-firstname" type="text/template">
    <input
        type="text"
        value="{{{ _.escape( data.value ) }}}"
        class="{{{ data.renderClasses() }}} nf-element"
        id="nf-field-{{{ data.id }}}"
        name="{{ data.custom_name_attribute || 'nf-field-' + data.id + '-' + data.type }}"
        {{{ data.maybeDisableAutocomplete() }}}
        {{{ data.renderPlaceholder() }}}
        aria-invalid="false"
        aria-describedby="<# if( data.desc_text ) { #>nf-description-{{{ data.id }}} <# } #>nf-error-{{{ data.id }}}"
        aria-labelledby="nf-label-field-{{{ data.id }}}"
        {{{ data.maybeRequired() }}}
    >
</script>
<script id='tmpl-nf-field-input' type='text/template'>
    <input id="nf-field-{{{ data.id }}}" name="nf-field-{{{ data.id }}}" aria-invalid="false" aria-describedby="<# if( data.desc_text ) { #>nf-description-{{{ data.id }}} <# } #>nf-error-{{{ data.id }}}" class="{{{ data.renderClasses() }}} nf-element" type="text" value="{{{ _.escape( data.value ) }}}" {{{ data.renderPlaceholder() }}} {{{ data.maybeDisabled() }}}
           aria-labelledby="nf-label-field-{{{ data.id }}}"

            {{{ data.maybeRequired() }}}
    >
</script>
<script id="tmpl-nf-field-lastname" type="text/template">
    <input
        type="text"
        value="{{{ _.escape( data.value ) }}}"
        class="{{{ data.renderClasses() }}} nf-element"
        id="nf-field-{{{ data.id }}}"
        name="{{ data.custom_name_attribute || 'nf-field-' + data.id + '-' + data.type }}"
        {{{ data.maybeDisableAutocomplete() }}}
        {{{ data.renderPlaceholder() }}}
        aria-invalid="false"
        aria-describedby="<# if( data.desc_text ) { #>nf-description-{{{ data.id }}} <# } #>nf-error-{{{ data.id }}}"
        aria-labelledby="nf-label-field-{{{ data.id }}}"
        {{{ data.maybeRequired() }}}
    >
</script>
<script id="tmpl-nf-field-email" type="text/template">
	<input
		type="email"
		value="{{{ _.escape( data.value ) }}}"
		class="{{{ data.renderClasses() }}} nf-element"
		id="nf-field-{{{ data.id }}}"
		name="{{ data.custom_name_attribute || 'nf-field-' + data.id + '-' + data.type }}"
		{{{data.maybeDisableAutocomplete()}}}
		{{{ data.renderPlaceholder() }}}
		{{{ data.maybeDisabled() }}}
		aria-invalid="false"
		aria-describedby="<# if( data.desc_text ) { #>nf-description-{{{ data.id }}} <# } #>nf-error-{{{ data.id }}}"
		aria-labelledby="nf-label-field-{{{ data.id }}}"
		{{{ data.maybeRequired() }}}
	>
</script>
<script id="tmpl-nf-field-checkbox" type="text/template">
	<input id="nf-field-{{{ data.id }}}"
	       name="nf-field-{{{ data.id }}}"
	       aria-describedby="<# if( data.desc_text ) { #>nf-description-{{{ data.id }}} <# } #>nf-error-{{{ data.id }}}"
	       class="{{{ data.renderClasses() }}} nf-element"
	       type="checkbox"
	       value="1" {{{ data.maybeDisabled() }}}{{{ data.maybeChecked() }}}
	       aria-labelledby="nf-label-field-{{{ data.id }}}"

			{{{ data.maybeRequired() }}}
	>
</script>
<script id="tmpl-nf-field-submit" type="text/template">

<# 
let myType = data.type
if('save'== data.type){
	myType = 'button'
}
#>
<input id="nf-field-{{{ data.id }}}" class="{{{ data.renderClasses() }}} nf-element " type="{{{myType}}}" value="{{{ ( data.maybeFilterHTML() === 'true' ) ? _.escape( data.label ) : data.label }}}" {{{ ( data.disabled ) ? 'aria-disabled="true" disabled="true"' : '' }}}>

</script><script id='tmpl-nf-field-button' type='text/template'>
    <button id="nf-field-{{{ data.id }}}" name="nf-field-{{{ data.id }}}" class="{{{ data.classes }}} nf-element">
        {{{ ( data.maybeFilterHTML() === 'true' ) ? _.escape( data.label ) : data.label }}}
    </button>
</script>  <script type="text/javascript">window.NREUM||(NREUM={});NREUM.info={"beacon":"bam.nr-data.net","licenseKey":"NRJS-1cbf18cb11c6a4f89a0","applicationID":"1546597350","transactionName":"NQQBMhEAXkcDBxVYXQxOIgUXCF9aTQ0PVVca","queueTime":0,"applicationTime":990,"atts":"GUMCRFkaTUk=","errorBeacon":"bam.nr-data.net","agent":""}</script></body>
</html>
